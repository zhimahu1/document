#### 创建ERP订单

入口： com.jd.airplane.service.order.book.AbstractBookService **public final SubmitOrderResult createErpOrder(BookVO<T> bookVO)**

1.在入参 **bookVO** 中获取订单信息对象 **AirAirplaneOrder airplaneOrder**
2.构建空的 **ErpOrderedResult erpResult** 对象
## 3 这个判断中 有三行 无用代码 建议删除
3.如果当前订单是 **0元改期单** 直接调用 **createResult(bookVO)** 方法 返回结果 
4.调用 **createErpOrderNew** 方法 获取 **erpResult** 信息
5.如果第 4 步的处理过程中抛出了自定义京米促销ERP下单失败异常 **JmiErpBookFail e** 捕获异常并进行处理
      向外抛出自定义下单异常 **throw new BookingException("stage_createErpOrder", 24, e)** 
  如果第 4 步的处理过程中抛出了自定义ERP下单失败异常 **ErpBookFail e** 捕获异常并进行处理
      向外抛出自定义下单异常 **throw new BookingException("stage_createErpOrder", 3, e)**
  如果第 4 步的处理过程中抛出了上述之外的其它异常 捕获异常并进行处理
      向外抛出自定义下单异常 **throw new BookingException("stage_createErpOrder", 3, e)**
6.如果 **erpResult** 为空或者标识为false或者订单号为0 **erpResult == null || !erpResult.isFlag() || erpResult.getOrderId() == 0**
  向外抛出自定义下单异常 **throw new BookingException("stage_createErpOrder", 2, e)** 表示预定失败
7.获取erp订单号 **erpOrderCode - airplaneOrder.getOrderCode()**
8.获取往返拆单中的另一个子单信息 **AirAirplaneOrder orderSplit = bookVO.getOrderSubmit().getOrderSplit()**
9.判断是否为往返拆单 **bookVO.getSplitFlag() - true ？**
  Y： 为子订单 **airplaneOrder** 对象和另一个子单 **orderSplit** 对象设置父订单号 **parentOrderCode - erpResult.getOrderId()** 为另一个子单 **orderSplit** 对象设置订单状态 **orderStatus - 1（等待付款）** 
  N： 为订单 **airplaneOrder** 对象设置订单号 **orderCode - erpResult.getOrderId()** 为去程航班设置订单号 **bookVO.getFlightGo().setOrderId(erpResult.getOrderId())**
      如果是往返程的订单 **FlightType.RT.getName().equalsIgnoreCase(airplaneOrder.getOrderType()) - true**
          为返程航班设置订单号 **bookVO.getFlightBack().setOrderId(erpResult.getOrderId())**
10.为订单 **airplaneOrder** 对象设置订单状态 **orderStatus - 1（等待付款）** 
11.判断是否为往返拆单 **bookVO.getSplitFlag() - true ？**
   Y： 获取提单信息 **OrderSubmit orderSubmit = bookVO.getOrderSubmit()** 获取父订单原订单号 **oldMainOrderCode - orderSubmit.getMainOrder().getOrderCode()** 调用 **updateOrderERPInfo(oldMainOrderCode, erpResult.getOrderId(), erpOrderCode, orderSplit.getOrderCode(), orderSubmit)** 方法 更新数据
   N： 调用 **updateOrderERPInfo(bookVO.getOrderSubmit(), erpOrderCode)** 方法 更新数据
12.调用 **setFlightRefundProvision(bookVO)** 方法 保存航班退改签信息
13.判断是否为往返拆单 **bookVO.getSplitFlag() - true ？**
   Y： 调用 **airplaneOrderService.insertProcess(erpResult.getOrderId())** 方法 插入订单轨迹至数据库
   N： 调用 **airplaneOrderService.insertProcess(airplaneOrder.getOrderCode())** 方法 插入订单轨迹至数据库
14.为订单 **airplaneOrder** 对象赋值： **skuIdList - erpResult.getSkuIdlist()**
15.调用 **createResult(bookVO)** 方法 返回结果 

#### 创建订单提交结果返回对象

入口： com.jd.airplane.service.order.book.AbstractBookService **private SubmitOrderResult createResult(BookVO<T> bookVO)**

1.构建空的 **SubmitOrderResult result** 对象
2.给**result** 对象赋值： **state - 1 - 下单成功**
3.在入参 **bookVO** 中获取支付信息对象 **OrderPayment orderPayment**
4.如果 **在线支付金额为0**
  给**result** 对象赋值： **state - 11 - 检测京东资产支付成功**
5.在入参 **bookVO** 中获取订单信息对象里的订单号 **message - bookVO.getAirplaneOrder().getOrderCode().toString()**
6.如果是往返拆单 **bookVO.getSplitFlag() - true**
  将订单号更改为父订单号 **message - bookVO.getAirplaneOrder().getParentOrderCode().toString()**
7.给**result** 对象赋值： **order - bookVO.getAirplaneOrder()； message - message**
8.返回 **result** 对象

#### 创建新的ERP订单信息

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **public ErpOrderedResult createErpOrderNew(OrderSubmit orderSubmit) throws JmiErpBookFail,ErpBookFail,Exception**
日志： 正式 - /export/Logs/jipiao.360buy.com/order-submit.log； 测试 - /export/Logs/logs_web/order-submit.log

1.在入参 **orderSubmit** 中获取订单信息对象 **AirAirplaneOrder order**
2.在入参 **orderSubmit** 中获取配送信息对象 **AirContactInfo contactInfo**
3.在入参 **orderSubmit** 中获取下单IP地址 **ipAddress**
4.在入参 **orderSubmit** 中获取保险总销售加 **totalInsureSaleMoney**
5.构建 **ErpOrderBean bean** 对象
6.判断是否为往返拆单 **orderSubmit.getSplitFlag() - true ？**
  Y： 将 **bean** 对象中的订单总金额 赋值为两个子订单的总金额之和： **orderPrice - order.getOrderMoney() + orderSubmit.getOrderSplit().getOrderMoney()**
  N： 将 **bean** 对象中的订单总金额 赋值为订单总金额： **orderPrice - order.getOrderMoney()**
7.为 **bean** 对象赋值 
  **userId - order.getUserId()； userLevel - Integer.valueOf(order.getUserLevel())； customerName - contactInfo.getContactName()；**
  **mobile - contactInfo.getContactEmail()； clientIpAddress - ipAddress； port - orderSubmit.getPort()； totalInsureSaleMoney - totalInsureSaleMoney**
  **venderId - String.valueOf(order.getSourceId())； venderName - orderSubmit.getOuchInfo().getVenderName()； uuid - order.getOrderUUID()； cookies - orderSubmit.getCookies()**
  **ticketTypeList - buildTicketTypeList(orderSubmit)； insureTypeList - buildInsureTypeList(orderSubmit)； itineraryExpressType - buildItineraryExpressType(orderSubmit)**
## 8 可以放在 buildItineraryExpressType(orderSubmit) 方法中完成
8.如果是往返拆单 **orderSubmit.getSplitFlag() - true**
  获取Erp行程单快递配送收费类型对象 **ItineraryExpressType itineraryExpressType = bean.getItineraryExpressType()**
  如果Erp行程单快递配送收费类型对象不为空 **itineraryExpressType != null**
  为 **itineraryExpressType** 对象赋值 **groupNum - 1**
  构建回程Erp行程单快递配送收费类型对象 **ItineraryExpressType itineraryExpressTypeBack = this.buildItineraryExpressTypeBack(orderSubmit)**
  如果回程Erp行程单快递配送收费类型对象不为空 **itineraryExpressTypeBack != null**
  为 **itineraryExpressTypeBack** 对象赋值 **groupNum - 2**
9.构建空的 **ErpOrderedResult result** 对象
10.调用 **newCreateErpOrder** 方法 获取 **result** 信息
11.判断获取 **result** 信息是否成功并且订单号是否不为0 **result.isFlag() && result.getOrderId() != 0 ？**
   Y： 调用 **airplaneAlarmCountTypeMessage(MemcachAlarmConstants.INTF_ERP_ORDER_KRY, true)** 方法 记录座位预定失败次数
   N： 判断是否为订单金额是否改变 **result.isErpOrderMoneyHasChange() - true ？**
       Y： 打印 **京米促销erp下单失败** 日志 抛出 **京米促销erp下单失败** 异常
       N： 抛出 **ERP下单返回结果为空或状态为false** 异常
12.如果 步骤 10/11 过程中产生异常 捕捉异常进行处理
   打印 **ERP下单失败** 日志 生成 **ERP下单告警日志** 插入至数据库 如果插入数据库过程中产生异常 捕捉异常进行处理 打印 **机票前台ERP下单接口记录告警日志异常** 日志
   调用 **airplaneAlarmCountTypeMessage(MemcachAlarmConstants.INTF_ERP_ORDER_KRY, false)** 方法 记录座位预定失败次数
13.返回结果 **result**

#### 构建Erp下单机票类型对象集合

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private List<TicketType> buildTicketTypeList(OrderSubmit orderSubmit)**

1.构建Erp下单机票类型对象集合 **List<TicketType> ticketTypeList**
2.如果乘机人中存在成人 **orderSubmit.getAdtNum() > 0** 进入 **buildTicketType** 方法 将返回成人的Erp下单机票类型对象填加到 **ticketTypeList** 集合中
  如果是往返程 **orderSubmit.getMark() == 1** 再次进入 **buildTicketType** 方法 将返程的成人的Erp下单机票类型对象填加到 **ticketTypeList** 集合中
3.如果乘机人中存在儿童 **orderSubmit.getChdNum() > 0** 进入 **buildTicketType** 方法 将返回儿童的Erp下单机票类型对象填加到 **ticketTypeList** 集合中
  如果是往返程 **orderSubmit.getMark() == 1** 再次进入 **buildTicketType** 方法 将返程的儿童的Erp下单机票类型对象填加到 **ticketTypeList** 集合中
4.如果乘机人中存在婴儿 **orderSubmit.getInfNum() > 0** 进入 **buildTicketType** 方法 将返回婴儿的Erp下单机票类型对象填加到 **ticketTypeList** 集合中
  如果是往返程 **orderSubmit.getMark() == 1** 再次进入 **buildTicketType** 方法 将返程的婴儿的Erp下单机票类型对象填加到 **ticketTypeList** 集合中
5.返回 **ticketTypeList** 集合

#### 构建Erp下单机票类型对象

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private TicketType buildTicketType(AirFlightInfo flightInfo, int ticketNum, TicketTypeEnum ticketTypeEnum, String tripType)**
日志： 正式 - /export/Logs/jipiao.360buy.com/book-fail.log； 测试 - /export/Logs/logs_web/book-fail.log

1.构建Erp下单机票类型对象 **TicketType ticketType**
2.判断是否是去程 **tripType == 0 ？**
  Y： 将 **ticketType** 对象中的组别 赋值为： **groupNum - 1**
  N： 将 **ticketType** 对象中的组别 赋值为： **groupNum - 2**
3.构建机票类型 **typeName** ： **出发城市名称-到达城市名称（乘机人类型）** 乘机人类型： **ADT - 成人； CHD - 儿童； INF - 婴儿**
4.将机票类型 **typeName** 赋值到 **ticketType** 对象中
5.将对应乘机人类型的乘机人数量 **typeNum** 赋值到 **ticketType** 对象中 **Number - typeNum**
## 6/7/8 应当合并
6.判断乘机人类型 **ticketTypeEnum**
  ADT： **ticketType** 对象中的票价为 **price - flightInfo.getTotal()**
  CHD： **ticketType** 对象中的票价为 **price - flightInfo.getChildTotal()**
  INF： **ticketType** 对象中的票价为 **price - flightInfo.getInfantTotal()**
7.判断乘机人类型 **ticketTypeEnum**
  ADT： 为**ticketType** 对象赋值 **promoSku - flightInfo.getActSkuId()； rfId - flightInfo.getRfId()； discountMoney - flightInfo.getReducePrice()**
8.如果是成人且机票包含促销立减 **ticketTypeEnum - ADT && hasPromotionReduce - true**
  根据SKUId **ticketType.getPromoSku()** 查询数据表 **AIR_PROM_BDATA_SKU** 中 **state - 1** 在用 的SKU集合 **List<SKUEntity> entitylist**
  集合如果不为空 **entitylist.isEmpty() - false** 取第一个元素返回SKU基础信息对象 **SKUEntity promSku**
  判断SKU基础信息对象是否为空 **promSku != null ？** 
  Y： 为**ticketType** 对象赋值 **skuPrice - promSku.getClazzPrice()**
  N： 打出错误日志并抛出自定义异常 **ErpBookFail - errorMsg - "促销立减SKU不存在,构建商品-票类型失败,skuId=" + ticketType.getPromoSku()**
9.返回 **ticketType** 对象

#### 构建Erp下单保险类型对象集合

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private List<InsureType> buildInsureTypeList(OrderSubmit orderSubmit)**

1.构建Erp下单保险类型对象集合 **List<InsureType> insureTypeList**
2.如果订单有保险 **1 == orderSubmit.getOrder().getIsSafe().intValue()**
  获取去程乘机人信息集合 **List<AirPassengerInfo> gopassengers = orderSubmit.getGoPassengerList()**
  构建保险SKU数量map **Map<String, Integer> insurSkuCountMap** 构建保险SKUmap **Map<String, InsuranceInfo> insurSkuInfoMap**
  遍历去程乘机人信息集合 **AirPassengerInfo gopassenger : gopassengers** 
  获取乘机人中的保险信息集合 **List<InsuranceInfo> insuranceInfoList = gopassenger.getInsuranceInfoList()**
  判断保险信息集合是否为空 **insuranceInfoList == null || insuranceInfoList.isEmpty() ？**
  Y： 遍历保险信息集合 **InsuranceInfo insuranceInfo : insuranceInfoList** 
      根据保险产品码获取保险SKU **String sku = String.valueOf(airInsuranceFacadeWrap.getInsurInfoByProductCode(insuranceInfo.getProductCode()).getSku())**
      根据SKU获取 **insurSkuCountMap** 的value值 **oldVal** 如果**oldVal != null** 新的value值为 当前保险的购买数量加上旧值 **insurSkuCountMap.put(sku, oldVal + insuranceInfo.getInsuranceCnt())**
      根据SKU将保险信息 **insuranceInfo** 存入 **insurSkuInfoMap**
  N： 继续遍历 **gopassengers**
  遍历保险SKUmap **Map.Entry<String, InsuranceInfo> entry : insurSkuInfoMap.entrySet()**
      根据SKU获取获取 **insurSkuCountMap** 的value值 **int num = insurSkuCountMap.get(entry.getKey())**
      构建Erp下单保险类型对象 **InsureType insureType**
      为 **insureType** 对象赋值 **typeName - entry.getValue().getProductName()**
      判断是否为往返拆单 **orderSubmit.getSplitFlag() - true ？**
      Y： 为 **insureType** 对象赋值 **groupNum - 1**
      N： 如果是回程 **HAS_BACK_TICKET.equals(orderSubmit.getMark())** 保险数量翻倍 **num = num * 2**
      为 **insureType** 对象赋值 **number - num**
      ## 下面这行代码有些重复 key值即是SKU
      根据保险产品码获取保险SKU **String sku = String.valueOf(airInsuranceFacadeWrap.getInsurInfoByProductCode(entry.getValue().getProductCode()).getSku())**
      为 **insureType** 对象赋值 **sku - sku**
      为 **insureType** 对象赋值 **price - entry.getValue().getSalePrice().getAmount().longValue()**
      将 **insureType** 对象加入到集合 **insureTypeList** 中去
  ## 以下逻辑应该和去程进行合并 根据航程进行个别逻辑区分
  如果是往返拆单 **orderSubmit.getSplitFlag() - true**
      获取回程乘机人信息集合 **List<AirPassengerInfo> backPassengers = orderSubmit.getBackPassengerList()**
      构建回程保险SKU数量map **Map<String, Integer> insurSkuCountMap** 构建回程保险SKUmap **Map<String, InsuranceInfo> insurSkuInfoMap**
      将SKU赋值为国内返程30元航空意外险 **sku -  TicketInsuranceSkuEnum.INSURANCESKU2_BACK.getSku()**
      遍历返程乘机人信息集合 **AirPassengerInfo backPassenger : backPassengers** 
      获取乘机人中的保险信息集合 **List<InsuranceInfo> insuranceInfoListBack = backPassenger.getInsuranceInfoList()**
      判断保险信息集合是否为空 **insuranceInfoListBack == null || insuranceInfoListBack.isEmpty() ？**
      Y： 遍历保险信息集合 **InsuranceInfo insuranceInfo : insuranceInfoListBack**
          根据SKU获取 **insurSkuCountMapBack** 的value值 **oldVal** 如果**oldVal != null** 新的value值为 当前保险的购买数量加上旧值 **insurSkuCountMapBack.put(sku, oldVal + insuranceInfo.getInsuranceCnt())**
          根据SKU将保险信息 **insuranceInfo** 存入 **insurSkuInfoMapBack**
      N： 继续遍历 **backPassengers**
      遍历保险SKUmap **Map.Entry<String, InsuranceInfo> entry : insurSkuInfoMapBack.entrySet()**
      根据SKU获取获取 **insurSkuCountMapBack** 的value值 **int num = insurSkuCountMapBack.get(entry.getKey())**
      构建Erp下单保险类型对象 **InsureType insureType**
      为 **insureType** 对象赋值 **typeName - entry.getValue().getProductName()**
      为 **insureType** 对象赋值 **groupNum - 2**
      为 **insureType** 对象赋值 **number - num**
      为 **insureType** 对象赋值 **sku - sku**
      为 **insureType** 对象赋值 **price - entry.getValue().getSalePrice().getAmount().longValue()**
      将 **insureType** 对象加入到集合 **insureTypeList** 中去
3.返回集合 **insureTypeList**

#### 构建Erp行程单快递配送收费类型对象

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private ItineraryExpressType buildItineraryExpressType(OrderSubmit orderSubmit)**

1.判断配送费是否大于0 **orderSubmit.getDispatchInfo().getSellingPrice() != null && orderSubmit.getDispatchInfo().getSellingPrice().doubleValue() > 0 ？**
  Y： 构建Erp行程单快递配送收费类型对象 **ItineraryExpressType itineraryExpressType** 
      为 **itineraryExpressType** 对象赋值 **sku - TicketInsuranceSkuEnum.JIPIAO_ITINERARY_EXPRESS_SKU.getSku()**
      为 **itineraryExpressType** 对象赋值 **number - 1**
      为 **itineraryExpressType** 对象赋值 **price - orderSubmit.getDispatchInfo().getSellingPrice().intValue()**
      为 **itineraryExpressType** 对象赋值 **typeName - MessageFormat.format("行程单配送费{0}元", orderSubmit.getDispatchInfo().getSellingPrice().intValue())**
      返回Erp行程单快递配送收费类型对象 **itineraryExpressType**
  N： 返回NULL

#### 构建回程Erp行程单快递配送收费类型对象

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private ItineraryExpressType buildItineraryExpressTypeBack(OrderSubmit orderSubmit)**

1.判断配送费是否大于0 **orderSubmit.getDispatchInfo().getDeliveryTypeBack() != null && orderSubmit.getDispatchInfo().getSellingPriceBack().intValue() > 0 ？**
  Y： 构建Erp行程单快递配送收费类型对象 **ItineraryExpressType itineraryExpressType** 
      为 **itineraryExpressType** 对象赋值 **sku - TicketInsuranceSkuEnum.JIPIAO_ITINERARY_EXPRESS_BACK_SKU.getSku()**
      为 **itineraryExpressType** 对象赋值 **number - 1**
      为 **itineraryExpressType** 对象赋值 **price - orderSubmit.getDispatchInfo().getSellingPriceBack().intValue()**
      为 **itineraryExpressType** 对象赋值 **typeName - MessageFormat.format("行程单配送费{0}元", orderSubmit.getDispatchInfo().getSellingPriceBack().intValue())**
      返回Erp行程单快递配送收费类型对象 **itineraryExpressType**
  N： 返回NULL

#### 生成erp订单

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private ErpOrderedResult newCreateErpOrder(final ErpOrderBean orderBean, ErpOrderPayment erpOrderPayment, OrderSubmit orderSubmit) throws Exception**
日志： **log** 正式 - /export/Logs/jipiao.360buy.com/order-submit.log； 测试 - /export/Logs/logs_web/order-submit.log
    **erp_order_log** 正式 - /export/Logs/jipiao.360buy.com/erp_order.log； 测试 - /export/Logs/logs_web/erp_order.log 

1.构建 **ErpOrderedResult erpOrderResult** 对象
2.如果订单支付金额大于50000 **orderBean.getOrderPrice() >= 50000** 
  为 **erpOrderResult** 对象赋值 **flag - false； message - "机票订单金额大于50000，请重新选择！"**
  返回 **erpOrderResult** 对象
3.如果当前订单的Erp下单机票类型对象集合数量大于6 **orderBean.getTicketTypeList().size() > 6**
  为 **erpOrderResult** 对象赋值 **flag - false； message - "ticket type more than 4"**
  返回 **erpOrderResult** 对象
4.构建SKU数据对象集合 **List<ErpSku> skuList**
  调用 **ticketType2ErpSku(orderBean.getTicketTypeList(), orderSubmit.getMark())** 方法 将机票分类信息转换成sku数据 添加到 **skuList** 集合中去
  调用 **insureType2ErpSku(orderBean.getInsureTypeList())** 方法 将保险分类信息转换成sku数据 添加到 **skuList** 集合中去
  调用 **itineraryExpressType2ErpSku(orderBean.getItineraryExpressType())** 方法 将行程单分类信息转换成sku数据 **ErpSku itineraryExpressSku**
  如果 **itineraryExpressSku** 对象不为空 **null!=itineraryExpressSku** 将 **itineraryExpressSku** 对象添加到 **skuList** 集合中去
5.构建 **ErpOrder erpOrder** 对象
  为 **erpOrder** 对象赋值： **skuList - skuList； pin - orderBean.getUserId()**
6.如果商家ID是自营 **CompanyEnum.COMPANY_SELFBSP.getKey().equals(orderBean.getVenderId())** 为 **erpOrder** 对象赋值 **companyBranch - 612（机构id - 360度主体）**
  如果商家ID是航司旗舰店 **AirCompanyUtil.isAirCompany(orderBean.getVenderId())** 为 **erpOrder** 对象赋值 **companyBranch - 543（机构id - pop机构）**
  如果商家ID非以上两种情况 判断是否需要开打发票 **orderSubmit.getOrder().getInvoiceForVopAndCT() == 1 ？**
  Y： 为 **erpOrder** 对象赋值 **companyBranch - 722（机构id - 六艺旅行社主体）**
  N： 为 **erpOrder** 对象赋值 **companyBranch - 543（机构id - pop机构）**
7.为 **erpOrder** 对象赋值： **orderType - 35（国内机票业务线类型）； paymentType - 4（在线支付）； putType - 3（不开发票）**
8.调用 **buildCartVO(orderBean,skuList,orderSubmit)** 方法 获取 **Result result** 对象
9.如果 **result** 对象返回结果为false **result.isSuccess() - false**
  返回结果 **(ErpOrderedResult)result.get("erpOrderedResult")**
10.从 **result** 对象中获取 **CartVO cartVO** 对象
11.构建订单参数信息对象 **OrderParam orderParam**
   为 **orderParam** 对象赋值： **orderGuid - orderBean.getUuid()； pin - orderBean.getUserId()**
12.构建余额参数信息对象 **BalanceParam balanceParam**
   为 **balanceParam** 对象赋值： **useBalance - erpOrderPayment.isBalance()**
13.为 **orderParam** 对象赋值： **balance - balanceParam**
14.从入参 **erpOrderPayment** 中获取优惠券信息集合 **List<CouponVO> couponVOList**
15.构建优惠券参数信息集合 **List<CouponParam> couponList**
16.构建字符串变量 **StringBuilder couponIds**
17.如果优惠券信息集合集合不为空 **couponVOList != null && couponVOList.size() > 0**
   遍历优惠券信息集合 **CouponVO couponVO : couponVOList**
       构建优惠券参数信息对象 **CouponParam couponParam**
       为 **couponParam** 赋值： **couponId - couponVO.getId()**
       在字符串变量 **couponIds** 中拼接优惠券信息id **couponIds.append(couponVO.getId() + "-")**
       将优惠券参数信息对象 **couponParam** 添加到优惠券参数信息集合 **couponList** 中去
  为 **orderParam** 对象设置优惠券参数： **usedCoupons - couponList**
18.打印 **"pin=" + orderBean.getUserId() + ",orderId=" + orderBean.getUuid() + "totalPrice："+ orderBean.getOrderPrice() + " isBalance：" + erpOrderPayment.isBalance() + "  couponIds:" + couponIds.toString()+ "  onlineMoney: " + erpOrderPayment.getOnlineMoney() + "\r\n"** 日志
19.为 **orderParam** 对象赋值： **orderNeedMoney - erpOrderPayment.getOnlineMoney()**
20.构建 **CombinationPaymentParam payType** 对象
   为 **payType** 对象赋值： **mainPaymentType - erpOrder.getPaymentType()**
21.为 **orderParam** 对象赋值： **combinationPayment - payType**
22.构建 **AddressParam addressParam** 对象
   为 **addressParam** 对象赋值： **cityId - 72（写死的）； provinceId - 1（写死的）； countyId - 2819（写死的）； orgId - erpOrder.getCompanyBranch()； name - orderBean.getCustomerName()； mobile - orderBean.getMobile()； email - orderBean.getEmail()； addressDefault - "北京市海淀区"（写死的）**
23.为 **orderParam** 对象赋值： **address - addressParam**
24.构建 **GeneralFreightParam generalFreightParam = new GeneralFreightParam(new BigDecimal(0),Integer.parseInt(orderBean.getVenderId()))** 对象
25.构建 **OrderFreightParam freight = new OrderFreightParam(generalFreightParam, null, null,null,null,null,null)** 对象
26.为 **orderParam** 对象赋值： **freight - freight**
27.构建 **ClientInfo clientInfo** 对象
   为 **clientInfo** 对象赋值： **clientIP - orderBean.getClientIpAddress()； bussinessType - 100016（写死的）； webOriginId - 3（写死的）； serverName - "机票系统"（写死的）； userIP - orderBean.getClientIpAddress()； port - orderBean.getPort()； originId - 1（写死的）**
28.如果订单来自手机端 **orderSubmit.getSourceType() == 1 || orderSubmit.getSourceType() == 8**
  为 **clientInfo** 对象赋值： **orderBean.getPort()； originId - 2（写死的）**
29.打印 **"clientInfo originId : " + clientInfo.getOriginId()** 日志
30.构建支付密码相关参数对象 **SubmitOrderNecessary submitOrderNecessary**
   为 **submitOrderNecessary** 对象赋值： **userPayPWD - orderSubmit.getOrderPayment().getPaymentPassword()； orderType - erpOrder.getOrderType()；sendPayTagMap - getSendPayMap(orderSubmit)； extTagMap - getKeplerMap(orderSubmit)**
31.获取下单与当前时间的时间差 **long duration = new Date().getTime() - orderSubmit.getOrder().getCreated().getTime()** （毫秒数）
32.将 **duration** 转换成秒 **long seconds = duration % 10 == 0 ? duration / 1000 : duration / 1000 + 1**
33.为 **submitOrderNecessary.getExtTagMap()** 对象赋值： **"AutoShowCancelTime", String.valueOf(30 * 60 - seconds)（半小时减去seconds 支付时间只有30分钟）； "AutoCancelTimeSource", "867"（jone应用部署id）**
34.打印 **"订单编号 : " + orderSubmit.getOrder().getOrderCd() + " 的sendPayTag打标参数 : " + submitOrderNecessary.getSendPayTagMap().toString()+ " 的kepler打标参数 : " + submitOrderNecessary.getExtTagMap().toString()+",existActivity="+orderSubmit.existsActivity()** 日志
35.构建 **List<Integer> list** 集合 用以判断哪些参数不用进行校验
36.如果不存在促销 **orderSubmit.existsActivity() - false**
   在 **list** 集合中添加 **1** 过滤促销的校验
37.在 **list** 集合中添加 **2** 过滤库存的校验
   在 **list** 集合中添加 **3** 过滤订单类型的校验
   在 **list** 集合中添加 **4** 过滤支付方式的校验
   在 **list** 集合中添加 **5** 过滤配送方式的校验
   在 **list** 集合中添加 **6** 过滤地址的校验
   在 **list** 集合中添加 **7** 没有运费
   在 **list** 集合中添加 **8** 过滤机构号的校验 以传过来的为准
   在 **list** 集合中添加 **9** 过滤支付密码的校验
   在 **list** 集合中添加 **10** 过滤商品的校验
   在 **list** 集合中添加 **11** 没有配送
38.如果不是往返拆单 **orderSubmit.getSplitFlag() - false**
   在 **list** 集合中添加 **12** 不走虚拟流程
39.构建 **SubmitOrderUnNecessary submitOrderUnNecessary** 对象
40.如果各业务线cookie不为空 **null != orderBean.getCookies() && !orderBean.getCookies().isEmpty()**
   ## 这里有一行 重复构建对象的代码 建议删除
   为 **submitOrderUnNecessary** 对象赋值： **OrderExtInfoMap - orderBean.getCookies()**
   打印 **"各业务线cookie dmpjs=" + orderBean.getCookies().get(CookieKeyConstants.COOKIE_SEM_DMPJS)+ ",jda=" + orderBean.getCookies().get(CookieKeyConstants.FLOW_SOURCE_JDA) + ",jdb="+ orderBean.getCookies().get(CookieKeyConstants.FLOW_SOURCE_JDB) + ",jdv="+ orderBean.getCookies().get(CookieKeyConstants.FLOW_SOURCE_JDV) + ",mtsubsite="+ orderBean.getCookies().get(CookieKeyConstants.FLOW_SOURCE_MT_SUBSITE) + ",pin="+ orderBean.getCookies().get(CookieKeyConstants.FLOW_SOURCE_PIN) + "，mtxid="+ orderBean.getCookies().get(CookieKeyConstants.FLOW_SOURCE_MT_XID) + ",unpl="+ orderBean.getCookies().get(CookieKeyConstants.FLOW_SOURCE_UNPL)** 日志
41.调用 **getSkuExtInfoMap(orderSubmit, skuList)** 方法 获取 **Map<Long, SkuExtInfo> skuExtInfoMap** 对象
42.如果是往返拆单 **orderSubmit.getSplitFlag() - true**
   调用 **buildUnNecessarySkuExtInfoMap(skuList)** 方法构建 **Map<Long, SkuExtInfo> splitOrderSkuExtInfoMap** 对象
   遍历SKU扩展信息map **Map.Entry<Long, SkuExtInfo> skuExtInfoMapEntry : skuExtInfoMap.entrySet()**
       获取SKUId **Long key = skuExtInfoMapEntry.getKey()**
       获取SKU扩展信息 **SkuExtInfo value = skuExtInfoMapEntry.getValue()**
       获取SKU扩展信息map **Map<String, String> skuExtendMap = value.getSkuExtendMap()**
       获取往返拆单的SKU扩展信息 **SkuExtInfo skuExtInfo = splitOrderSkuExtInfoMap.get(key)**
       组合SKU扩展信息 **skuExtendMap.putAll(skuExtInfo.getSkuExtendMap())**
43.为 **submitOrderUnNecessary** 对象赋值： **skuExtInfoMap - skuExtInfoMap**
44.构建资产使用校验参数对象（接入虚拟资产支付使用）**JmiPayRequest<JmiPayRuleRequestVO> jmiPayRuleRequest**
45.如果优惠券信息集合不为空或者下单时使用了虚拟资产 **CollectionUtils.isNotEmpty(couponList) || erpOrderPayment.isBalance()** 需要校验资产
   初始化 **jmiPayRuleRequest** 对象
   为 **jmiPayRuleRequest** 对象赋值： **appCode - String.valueOf(submitOrderNecessary.getOrderType())； uuid - UUID.randomUUID().toString()**
   构建 **JmiPayRuleRequestVO jmiPayRuleRequestVO** 对象
   为 **jmiPayRuleRequestVO** 对象赋值： **pin - orderParam.getPin()； total - (int) cartVO.getTotalPrice().getCent()； realTotal - erpOrderPayment.getOnlineMoney().intValue() * 100； orderType - submitOrderNecessary.getOrderType()**
   调用 **buildQueryCouponRequestFeatures(orderSubmit.getTicketgo(), orderSubmit.getTicketback())** 获取特性信息 为 **jmiPayRuleRequestVO** 对象的 **features** 属性赋值
   构建 **List<JmiPayRuleDetailVO> jmiPayRuleDetailVOList** 集合
   如果优惠券信息集合不为空 **CollectionUtils.isNotEmpty(couponList) - true**
       构建 **JmiPayRuleDetailVO jmiPayRuleDetailVO** 对象
       为 **jmiPayRuleDetailVO** 对象赋值： **payType - 3（写死的 1 - 京豆 2 - 余额 3 - 优惠券）； useTotal - (int) (orderSubmit.getOrderPayment().getCouponJingMoney() + orderSubmit.getOrderPayment().getCouponDongMoney())；**
       获取 **couponList** 集合中每个元素的id 为 **jmiPayRuleDetailVO** 对象赋值： 
            **jmiCoupons - Lists.transform(couponList, new Function<CouponParam, String>() {
					public String apply(CouponParam couponParam) {
						return couponParam.getCouponId();
					}
			  })**
       将 **jmiPayRuleDetailVO** 对象添加到 **jmiPayRuleDetailVOList** 集合中
       为 **jmiPayRuleRequestVO** 对象赋值： **jmiCouponPlatformRule - 0（WEB平台）**
       如果订单来源渠道是移动Mobile、移动APP、JD大客户、差旅、新差旅 **orderSubmit.getSourceType() in (1,8,3,4,11)**
           为 **jmiPayRuleRequestVO** 对象赋值： **jmiCouponPlatformRule - 0（JDAPP平台）**
       获取 **skuList** 集合中每个元素 构建 **WareSku wareSku** 对象 为 **List<WareSku> wareSkuList** 集合赋值：
            **wareSkuList - Lists.transform(skuList, new Function<ErpSku, WareSku>() {
					public WareSku apply(ErpSku erpSku) {
						WareSku wareSku = new WareSku();
						wareSku.setSkuId(String.valueOf(erpSku.getSkuId()));
						wareSku.setCategoryId(thirdLevelCategoryId);
						wareSku.setVenderId(Integer.valueOf(orderBean.getVenderId()));
						return wareSku;
					}
				})**
      为 **jmiPayRuleRequestVO** 对象赋值： **wareSkus - wareSkuList**
  为 **jmiPayRuleRequestVO** 对象赋值： **jmiPayRuleDetails - jmiPayRuleDetailVOList**
  为 **jmiPayRuleRequest** 对象赋值： **data - jmiPayRuleRequestVO**
46.构建是否使用了京券的标识 **boolean isHaveJingCoupon = false**
47.如果优惠券信息集合不为空 **CollectionUtils.isNotEmpty(couponVOList)**
   遍历优惠券信息集合 **CouponVO couponVO : couponVOList**
       如果是京券 **0 == couponVO.getCouponType()**
           将是否使用了京券的标识置为true **isHaveJingCoupon - true** 
           退出遍历循环
48.构建空的长短密码校验参数对象 **JmiPayRequest<JmiPayCheckPasswordVO> jmiPayReuest**
49.判断下单时是否使用了虚拟资产以及是否使用了京券 **!erpOrderPayment.isBalance() && !isHaveJingCoupon ？**
   ## Y： 这行是无用代码 建议更改判断方式
   N: 表示使用了虚拟资产以及使用了京券 
      初始化 **jmiPayReuest**	 对象 并赋值 **appCode - String.valueOf(submitOrderNecessary.getOrderType())**
      构建 **JmiPayCheckPasswordVO jmiPayCheckPasswordVO** 对象
      为 **jmiPayCheckPasswordVO** 对象赋值： **ip - clientInfo.getUserIP()； pin - orderParam.getPin()； pwd - submitOrderNecessary.getUserPayPWD()； data - jmiPayCheckPasswordVO**
50.构建虚拟镖局参数对象 **SubmitOrderInfo orderInfo**
   为 **orderInfo** 对象赋值： **userIp - clientInfo.getUserIP()； userPin - orderParam.getPin()； buyTime - new Date()； totalPay - cartVO.getTotalPrice().getCent()； orderType - submitOrderNecessary.getOrderType()**
   通过调用 **buildAirTicketFeature(orderSubmit.getOrder(),orderSubmit.getContactInfo().getContactPhone(), orderSubmit.getTicketgo(), orderSubmit.getGoPassengerList(),CollectionUtils.isNotEmpty(couponList) ? String.valueOf(couponVOList.get(0).getBatchId()) : "")** 方法 构建机票Feature信息为 **orderInfo** 对象赋值
51.构建 **Map<String, Object> map** 对象
   为 **map** 对象赋值： **"cartVO" - cartVO； "orderParam" - orderParam； "clientInfo" - clientInfo； "submitOrderNecessary" - submitOrderNecessary； "submitOrderUnNecessary" - submitOrderUnNecessary； "list" - list**
   **"orderBean" - orderBean； "orderSubmit" - orderSubmit； "jmiPayRuleRequest" - jmiPayRuleRequest； "jmiPayRequest" - jmiPayReuest； "orderInfo" - orderInfo**
52.调用 **jmiErpBook(map)** 方法 构建 **erpOrderResult** 对象
53.为 **erpOrderResult** 对象赋值： **skuList - skuList**
54.如果上述过程中出现了异常 捕获异常并进行处理
   为 **erpOrderResult** 对象赋值 **flag - false； message - "erp下单失败-orderId=" + orderBean.getUuid()** 
   打印 **"erp下单失败,pin=" + orderBean.getUserId() + ",orderId=" + orderBean.getUuid(), e** 错误日志
55.返回 **erpOrderResult** 对象

#### 构建ERP机票SKU

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private List<ErpSku> ticketType2ErpSku(List<TicketType> ticketList, String mark)**

1.构建SKU数据对象集合 **List<ErpSku> skuList**
2.遍历Erp下单机票类型对象集合 **int i = 0; i < ticketList.size(); i++**
  获取当前Erp下单机票类型对象 **TicketType ticket = ticketList.get(i)**
  构建SKU数据对象 **ErpSku sku**
  判断是否有促销立减 **ticket.hasPromotionReduce() - true ？**
  Y： 为 **sku** 对象赋值 **skuId - ticket.getPromoSku()； price - ticket.getSkuPrice()； discountMoney - ticket.getDiscountMoney()； promoId - ticket.getRfId()**
      如果存在SKU补价 **ticket.getSkuOffset() > 0** 需要调用 **buildCentSku(ticket,i)** 方法 为 **ticket** 对象填补一分钱SKU后 添加到 **skuList** 集合中
  N： 设置索引值 **int index = i** 如果是去程 **"0".equals(mark)** 将索引值翻倍 **index *= 2** 为 **sku** 对象赋值 **skuId - Long.parseLong(TicketInsuranceSkuEnum.getTicketSkuId(index))； price - ticket.getSkuOffset()**
  为 **sku** 对象赋值： **num - ticket.getNumber()； skuName - ticket.getTypeName()； groupNum - ticket.getGroupNum()**
  将 **sku** 对象添加到 **skuList** 集合中
3.返回 **skuList** 集合

#### 填补一分钱SKU

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private ErpSku buildCentSku(TicketType ticket,int skuIndex)**

1.构建SKU数据对象 **ErpSku centSku**
2.为 **centSku** 赋值： **skuId - Long.parseLong(TicketInsuranceSkuEnum.getTicketSkuId(skuIndex))； num - ticket.getNumber()； price - ticket.getSkuOffset()； skuName - ticket.getTypeName()； groupNum - ticket.getGroupNum()**
3.返回 **centSku** 对象

#### 按顺序获取国内机票sku,从0开始

入口： com.jd.airplane.enumtype.TicketInsuranceSkuEnum **public static String getTicketSkuId(int i)**

入参 **i** 为索引 范围为 **[0,5]** 
**0:"1000289361", "国内单程成人机票sku"** 
**1:"1000289291", "国内单程儿童机票sku"** 
**2:"1000289289", "国内往返成人机票sku"**
**3:"1000289283", "国内往返儿童机票sku"**
**4:"14184595712", "国内往返成人机票sku"**
**5:"14184649345", "国内往返儿童机票sku"**
1.如果 入参 **i** 的值小于0或者大于5 **i<0 || i>5**
  抛出异常 **"获取国内机票Sku失败, 索引i非法:" + i**
2.返回对应索引值的SKUId **TicketInsuranceSkuEnum.values()[i].getSku()**

#### 构建ERP保险SKU

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private List<ErpSku> insureType2ErpSku(List<InsureType> insureTypeList)**

1.构建SKU数据对象集合 **List<ErpSku> skuList**
2.如果Erp下单保险类型对象集合 **insureTypeList** 为空 **null == insureTypeList**
  返回 **skuList** 集合
3.构建保险SKU数据set **Set<String> insurSkuSet** 用于保存当前订单保险的所有sku值
4.遍历 **insureTypeList** 集合 **int i = 0; i < insureTypeList.size(); i++**
  获取当前Erp下单保险类型对象 **InsureType insureType = insureTypeList.get(i)**
  构建SKU数据对象 **ErpSku sku**
  为 **sku** 对象赋值： **groupNum - ticket.getGroupNum()； skuId - Long.parseLong(insureType.getSku())； num - ticket.getNumber()； price - insureType.getPrice()； skuName - ticket.getTypeName()**
  将 **sku** 对象添加到 **skuList** 集合中
## 5 这个遍历为无用代码 建议删除
5.遍历 **insureTypeList** 集合 **InsureType insureType : insureTypeList**
  将保险SKU添加到保险SKU数据set中去 **insurSkuSet.add(insureType.getSku())**
  打印 **"erp下单保险SKU集合元素值：insureType.getSku()=" + insureType.getSku()** 日志
6.返回 **skuList** 集合

#### 构建ERP行程单SKU

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private ErpSku itineraryExpressType2ErpSku(ItineraryExpressType itineraryExpressType)**

1.如果入参Erp行程单快递配送收费类型对象 **itineraryExpressType** 为空 **null == itineraryExpressType** 
  返回NULL
2.构建SKU数据对象 **ErpSku sku**
  为 **sku** 对象赋值： **skuId - Long.parseLong(itineraryExpressType.getSku())**
  为 **sku** 对象赋值： **num - itineraryExpressType.getNumber()**
  为 **sku** 对象赋值： **price - itineraryExpressType.getPrice()**
  为 **sku** 对象赋值： **skuName - itineraryExpressType.getTypeName()**
  为 **sku** 对象赋值： **groupNum - itineraryExpressType.getGroupNum()**
3.返回 **sku** 对象

#### 构建类目

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private Result buildCartVO(ErpOrderBean orderBean, List<ErpSku> skuList,OrderSubmit orderSubmit)**
日志： 正式 - /export/Logs/jipiao.360buy.com/erp_order.log； 测试 - /export/Logs/logs_web/erp_order.log 

1.打印 **"buildCartVO参数skuList=" + JSON.toJSONString(skuList)** 日志
2.构建 **Result result** 对象
  为 **result** 对象赋值： **success - true**
3.构建 **CartVO cartVO** 对象
4.构建 **List<ProductSetVO> products** 集合
5.构建 **long totalPrice = 0** 总价对象
6.构建 **long totalDiscountPrice = 0** 总优惠金额对象
7.遍历入参 **skuList** 集合 **ErpSku erpSku : skuList**
  构建 **ProductSetVO productSetVO** 对象
  构建 **SkuVO skuVo** 对象
  为 **skuVo** 赋值： **id - String.valueOf(erpSku.getSkuId())； cid - thirdLevelCategoryId（机票三级类目id）； name - erpSku.getSkuName()**
  如果当前订单存在促销并且是一分钱SKU **orderSubmit.existsActivity() && erpSku.isCentSku()**
      为 **skuVo** 赋值： **num - Integer.valueOf(String.valueOf(erpSku.getPrice())) * 100 * erpSku.getNum()** 将元转成分*sku数量
      为 **skuVo** 赋值： **price - new Money(1l)**
      为 **totalPrice** 赋值： **totalPrice += erpSku.getPrice() * erpSku.getNum()**
  如果当前订单存在促销并且不是一分钱SKU **orderSubmit.existsActivity() && !erpSku.isCentSku()**
      为 **skuVo** 赋值： **num - erpSku.getNum()； price - new Money(erpSku.getPrice(), 0)**
      为 **totalDiscountPrice** 赋值： **totalDiscountPrice += erpSku.getDiscountMoney()*erpSku.getNum()**
      为 **totalPrice** 赋值： **totalPrice += erpSku.getPrice() * erpSku.getNum()**
      构建 **PromotionVO promotion** 对象
      为 **promotion** 对象赋值： **promoId - erpSku.getPromoId()； discount - new Money(erpSku.getDiscountMoney(),0)；**
      为 **productSetVO** 对象赋值： **promotion - promotion**
  如果非以上两种情况 
      为 **skuVo** 赋值： **num - erpSku.getNum()； price - new Money(erpSku.getPrice(), 0)**
      为 **totalPrice** 赋值： **totalPrice += erpSku.getPrice() * erpSku.getNum()**
  构建 **OrderPopInfoVO orderPopInfoVO** 对象
  打印 **"erp下单SKUID值：erpSku.getSkuId()=" + erpSku.getSkuId() + ",skuPrice="+erpSku.getPrice()+",reducePrice="+erpSku.getDiscountMoney()+",num="+skuVo.getNum()+",  orderBean.getVenderId()=" + orderBean.getVenderId()+ ", orderBean.getVenderName()=" + orderBean.getVenderName()** 日志
  为 **orderPopInfoVO** 对象赋值： **venderId - Integer.parseInt(orderBean.getVenderId())； venderName - orderBean.getVenderName()； venderType - 8（写死的）**
  为 **skuVo** 赋值： **popInfo - orderPopInfoVO**
  为 **productSetVO** 对象赋值： **mainSku - skuVo**
  将 **productSetVO** 对象添加到 **products** 集合中去
8.为 **cartVO** 对象赋值： **totalPrice - new Money(totalPrice, 0)；**
10.如果当前订单存在促销 **orderSubmit.existsActivity() - true**
   为 **cartVO** 对象赋值： **totalDiscountMoney - new Money(totalDiscountPrice, 0)**
11.打印 **"erp下单总金额,orderPrice=" + orderBean.getOrderPrice() + ",totalPrice=" + totalPrice + ",totalPromotionPrice=" + totalDiscountPrice** 日志
12.如果下单总金额与计算总金额不符 **orderBean.getOrderPrice() != (totalPrice-totalDiscountPrice)**
   为 **result** 对象赋值： **success - false； **
   构建 **ErpOrderedResult erpOrderResult** 对象
   为 **erpOrderResult** 对象赋值： **flag - false； message - "下单时订单金额与机票计算金额不符合，请核实！"**
   为 **result** 对象赋值： **addDefaultModel - "erpOrderedResult", erpOrderResult**
   打印 **"\*\*\*\*\*\*\下单时订单金额与机票计算金额不符合,传入订单金额：" + orderBean.getOrderPrice() + ",实际计算金额：" + totalPrice** 错误日志
   返回 **result** 对象
13.为 **result** 对象赋值：  **addDefaultModel - "cartVO", cartVO**
14.返回 **result** 对象

#### SendPay打标操作

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **public Map<Integer, Integer> getSendPayMap(OrderSubmit orderSubmit)**

1.构建 **Map<Integer, Integer> resultMap** 对象
2.为 **resultMap** 对象赋值： **62（打标位数） - 1（打标枚举值）； 64（渠道打标位数） - 1（PC打标枚举值）**
3.如果是往返拆单 **orderSubmit.getSplitFlag() - true**
  为 **resultMap** 对象赋值： **165（机票往返拆单打标位数） - 1（机票往返拆单-打标值 1 - 纯虚拟 / 2 - 虚拟+实物 / 3 - 实物）**
4.为 **resultMap** 对象赋值： **168（二清打标位数） - 1（二清打标枚举值）**
5.如果开打发票 **orderSubmit.getOrder().getInvoiceForVopAndCT() == 1**
  为 **resultMap** 对象赋值： **130（大发票打标位数） - 1（大发票打标枚举值）**
## 第一个判断 与 2 逻辑重复 建议合并
6.如果订单来源渠道是网站、JD大客户、差旅、OneBox **orderSubmit.getSourceType() in （0，3，4，6）**
      为 **resultMap** 对象赋值： **64（渠道打标位数） - 1（PC打标枚举值）**
  如果订单来源渠道是移动M端（H5）**orderSubmit.getSourceType() == 1**
      为 **resultMap** 对象赋值： **64（渠道打标位数） - 2（mobile打标枚举值）**
      如果当前订单开普勒信息map不为空 **orderSubmit.getKeplerMap() != null && orderSubmit.getKeplerMap().size() > 0**
	      获取当前订单开普勒信息来源渠道 **source - orderSubmit.getKeplerMap().get("source")**
	      判断 **source** 值 
	          kepler-sdk -  为 **resultMap** 对象赋值： **101（开普勒打标位数） - 1（开普勒打标枚举值）； 103（开普勒打标位数） - 1（开普勒打标枚举值）**
	          kepler-m -    为 **resultMap** 对象赋值： **101（开普勒打标位数） - 1（开普勒打标枚举值）； 103（开普勒打标位数） - 2（开普勒打标枚举值）**
	          kepler-open - 为 **resultMap** 对象赋值： **101（开普勒打标位数） - 1（开普勒打标枚举值）； 103（开普勒打标位数） - 4（开普勒打标枚举值）**
  如果订单来源渠道是移动APP端 **orderSubmit.getSourceType() == 8**
      为 **resultMap** 对象赋值： **64（渠道打标位数） - 3（mobileApp打标枚举值）**
7.返回 **resultMap** 对象

#### KeplerMap打标操作

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **public Map<String, String> getKeplerMap(OrderSubmit orderSubmit)**

1.构建 **Map<Integer, Integer> resultMap** 对象
2.如果订单来源渠道是移动M端（H5）**orderSubmit.getSourceType() == 1**
  返回 **resultMap** 对象
3.从入参中获取开普勒信息map对象 **Map<String, String> orderKeplerMap = orderSubmit.getKeplerMap()**
4.如果开普勒信息map对象为空 **CollectionUtils.isEmpty(orderKeplerMap) - true**
  返回 **resultMap** 对象
5.如果开普勒信息map对象中的用户信息不为空 **orderKeplerMap.get("customerInfo") != null** 需要进行老版本兼容 将 customerInfo 转为 kepler-customerInfo
  为 **orderKeplerMap** 对象赋值： **kepler-customerInfo（开普勒打标枚举值） - orderKeplerMap.get("customerInfo")**
6.其他情况 需要将 **orderKeplerMap** 对象原样转为 Json 字符串 由最远端传入处理 为 **resultMap** 对象赋值： **projectid（开普勒打标枚举值） - JSON.toJSONString(orderKeplerMap)**
7.返回 **resultMap** 对象

#### 获取SKU扩展信息

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private Map<Long, SkuExtInfo> getSkuExtInfoMap(OrderSubmit orderSubmit, List<ErpSku> skuList)**
日志： 正式 - /export/Logs/jipiao.360buy.com/order-submit.log； 测试 - /export/Logs/logs_web/order-submit.log

1.构建 **Map<Long,SkuExtInfo> skuExtInfoMap** 对象
2.遍历入参 **skuList** 集合 **ErpSku erpSku:skuList**
  构建SKU扩展信息对象 **SkuExtInfo skuExtInfo**
  构建 **Map skuExtendMap** 对象
  如果当前订单存在促销并且促销id大于0并且SKU价格等于300 **orderSubmit.existsActivity() && erpSku.getPromoId() > 0 && erpSku.getPrice() == 300**
      为 **skuExtInfoMap** 对象赋值： **"virtual_num" - "0"**
  如果是机票SKU并且是成人SKU **erpSku.isTicketSku() && erpSku.isAduSku()** 详情见机票保险SKU枚举类 **TicketInsuranceSkuEnum** 
      为 **skuExtInfoMap** 对象赋值： **"virtual_num" - orderSubmit.getAdtNum()+""**
  如果是机票SKU并且是儿童SKU **erpSku.isTicketSku() && erpSku.isChdSku()** 详情见机票保险SKU枚举类 **TicketInsuranceSkuEnum**
      为 **skuExtInfoMap** 对象赋值： **"virtual_num" - orderSubmit.getChdNum()+""**
  如果是机票SKU并且是婴儿SKU **erpSku.isTicketSku() && erpSku.isInfSku()** 详情见机票保险SKU枚举类 **TicketInsuranceSkuEnum**
      为 **skuExtInfoMap** 对象赋值： **"virtual_num" - orderSubmit.getInfNum()+""**
  如果是保险SKU **erpSku.isInsureSku()** 详情见机票保险SKU枚举类 **TicketInsuranceSkuEnum**
      为 **skuExtInfoMap** 对象赋值： **"virtual_num" - erpSku.getNum()+""**
  如果非以上5种情况
      为 **skuExtInfoMap** 对象赋值： **"virtual_num" - "1"**
  为 **skuExtInfo** 对象赋值： **skuExtendMap - skuExtendMap**
  为 **skuExtInfoMap** 对象赋值： **erpSku.getSkuId() - skuExtInfo**
3.打印 **" pin="+orderSubmit.getPin()+" skuExtInfo =" + JSON.toJSONString(skuExtInfoMap)** 日志
4.返回 **skuExtInfoMap** 对象

#### 往返拆单使用 构造SKU拆分规则 不能传全量规则 有几个传几个

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private Map<Long, SkuExtInfo> buildUnNecessarySkuExtInfoMap(List<ErpSku> skuList)**
日志： 正式 - /export/Logs/jipiao.360buy.com/erp_order.log； 测试 - /export/Logs/logs_web/erp_order.log 

1.打印 **"拆单组织拆单规则方法参数：skuList=" + JSON.toJSONString(skuList)** 日志
2.构建 **Map<Long, SkuExtInfo> skuExtInfoMap** 对象
3.遍历入参 **skuList** 集合 **ErpSku erpSku : skuList**
  构建 **SkuExtInfo skuExtInfoGo** 对象
  构建 **Map<String, String> skuExtendMapGo** 对象
  为 **skuExtendMapGo** 对象赋值： **"virtualSkuSplitMark" - String.valueOf(erpSku.getGroupNum())； "virtualSkuOrderType" - "35"（国内机票业务线类型）**
  为 **skuExtInfoGo** 对象赋值： **skuExtendMap - skuExtendMapGo**
  为 **skuExtInfoMap** 对象赋值： **erpSku.getSkuId() - skuExtInfoGo**
4.打印 **"拆单组织拆单规则方法返回结果：skuExtInfoMap=" + JSON.toJSONString(skuExtInfoMap)** 日志
5.返回 **skuExtInfoMap** 对象

#### 构建特性信息 key1=商家ID key2=航司 key3=航线 key4=航班 key5=舱位

入口： com.jd.airplane.service.ticket.impl.AirplaneOrderServiceImpl **public String buildQueryCouponRequestFeatures(AirFlightInfo ticketgo, AirFlightInfo ticketback)**

1.构建 **Map<String, String> featureMap** 对象
2.为 **featureMap** 对象赋值 
  **"key1" - ticketgo.getSourceId() + (ticketback == null || StringUtil.isEmpty(ticketback.getSourceId()) ? "" : "," + ticketback.getSourceId())**
  **"key2" - ticketgo.getAirCode() + (ticketback == null || StringUtil.isEmpty(ticketback.getAirCode()) ? "" : "," + ticketback.getAirCode())**
  **"key3" - ticketgo.getDepcityCode() + "-" + ticketgo.getArrcityCode() + (ticketback == null || StringUtil.isEmpty(ticketback.getDepcityCode()) ? "" : "," + ticketback.getDepcityCode() + "- " + ticketback.getArrcityCode())**
  **"key4" - ticketgo.getAirplaneNumber() + (ticketback == null || StringUtil.isEmpty(ticketback.getAirplaneNumber()) ? "" : "," + ticketback.getAirplaneNumber())**
  **"key5" - ticketgo.getSeatCode() + (ticketback == null || StringUtil.isEmpty(ticketback.getSeatCode()) ? "" : "," + ticketback.getSeatCode())**
3.返回Json串 **JSON.toJSONString(featureMap)**

#### 构建机票Feature

入口： com.jd.airplane.rpc.riskControl.impl.OrderScortAgencyServiceImpl **public AirTicketFeature buildAirTicketFeature(AirAirplaneOrder airplaneOrder, String contactsMobile, AirFlightInfo ticketgo, List<AirPassengerInfo> listAirPassenger, String couponBatchId)**

1.构建 **AirTicketFeature airTicketFeature** 对象
2.为 **airTicketFeature** 对象赋值： **latelyFlightTime - ticketgo.getFlightDate()； seatingLevel - ticketgo.getSeatCode()； flightNumber - ticketgo.getAirplaneNumber()**
    **supplierID - String.valueOf(airplaneOrder.getSourceId())； mobile - contactsMobile； universalBehavior - couponBatchId； flightFrom - ticketgo.getDepcityCode()**
    **flightTo - ticketgo.getArrcityCode()； remainderVotes - ticketgo.getLeftTicketNum()； brandId - FlightRiskControlAirCodeConstants.getBrandIdByAirCode(ticketgo.getAirCode())**
3.构建 **List<PassengerInfo> listPassenger** 集合
4.如果入参 **listAirPassenger** 集合不为空 **listAirPassenger != null && listAirPassenger.size() > 0**
  遍历 **listAirPassenger** 集合 **AirPassengerInfo airPassengerInfo : listAirPassenger**
      构建乘机人信息对象 **PassengerInfo passenger**
      为 **passenger** 对象赋值： **name - airPassengerInfo.getPassengerName()； cardNo - airPassengerInfo.getPapersNumber()**
      将 **passenger** 对象添加到 **listPassenger** 集合中去
5.为 **airTicketFeature** 对象赋值： **passengers - listPassenger； strategyEID - airplaneOrder.getDeviceFingerprint()（设备指纹）**
6.返回 **airTicketFeature** 对象

#### 促销jmi下单记录

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **public ErpOrderedResult jmiErpBook(Map<String,Object> map)**
日志： 正式 - /export/Logs/jipiao.360buy.com/erp_order.log； 测试 - /export/Logs/logs_web/erp_order.log

1.构建 **CartVO cartVO**对象
2.从入参中获取 
  **OrderParam orderParam = (OrderParam) map.get("orderParam")** 对象
  **ClientInfo clientInfo = (ClientInfo) map.get("clientInfo")** 对象
  **SubmitOrderNecessary submitOrderNecessary = (SubmitOrderNecessary) map.get("submitOrderNecessary")** 对象
  **SubmitOrderUnNecessary submitOrderUnNecessary = (SubmitOrderUnNecessary) map.get("submitOrderUnNecessary")** 对象
  **JmiPayRequest<JmiPayRuleRequestVO> jmiPayRuleRequest = (JmiPayRequest<JmiPayRuleRequestVO>) map.get("jmiPayRuleRequest")** 对象
  **JmiPayRequest<JmiPayCheckPasswordVO> jmiPayReuest = (JmiPayRequest<JmiPayCheckPasswordVO>) map.get("jmiPayRequest")** 对象
  **SubmitOrderInfo orderInfo = (SubmitOrderInfo) map.get("orderInfo")** 对象
  **OrderSubmit orderSubmit = (OrderSubmit) map.get("orderSubmit")** 对象
  **List<Integer> list = (List<Integer>) map.get("list")** 对象
3.构建 **ErpOrderedResult erpOrderResult** 对象 国内机票erp下单监控对象 **jipiao.ticket.jmierpbook**
4.构建 **JmiTradeRequest tradeRequest** 对象
5.为 **tradeRequest** 对象赋值： **cartVO - cartVO（购物车信息）； clientInfo - clientInfo（客户端信息）； orderParam - orderParam（订单参数）； submitOrderNecessary - submitOrderNecessary； submitOrderUnNecessary - submitOrderUnNecessary（支付密码相关）； list - list（过滤哪些模块不校验）； jmiPayRuleRequest - jmiPayRuleRequest（优惠券前置所需要）； jmiPayReuest - jmiPayReuest（京米支付组件所需）； orderInfo - orderInfo** 详细参考 **京东ERP下单接口文档**
6.构建 **List<JmiPromoSkuSubtract> skuPromoSubtractList** 集合
7.如果去程有促销 **orderSubmit.getTicketgo().hasActivity() - true**
  构建 **JmiPromoSkuSubtract skuPromoSubtract = new JmiPromoSkuSubtract(orderSubmit.getTicketgo().getActSkuId(),orderSubmit.getTicketgo().getRfId(),orderSubmit.getAdtNum())** 对象
  将 **skuPromoSubtract** 添加到 **skuPromoSubtractList** 集合中去
8.如果返程有促销 **1 == orderSubmit.getMark() && orderSubmit.getTicketback().hasActivity()**
  构建 **JmiPromoSkuSubtract skuPromoSubtract2 = new JmiPromoSkuSubtract(orderSubmit.getTicketback().getActSkuId(), orderSubmit.getTicketback().getRfId(), orderSubmit.getAdtNum())** 对象
  将 **skuPromoSubtract2** 添加到 **skuPromoSubtractList** 集合中去
9.构建空的 **JmiPromoSubtract promoSubtract** 对象
10.如果 **skuPromoSubtractList** 集合数量大于0 **skuPromoSubtractList.size() > 0**
   初始化 **promoSubtract** 对象 **promoSubtract=new JmiPromoSubtract(35,cartVO.getTotalPrice().getCent(), orderSubmit.getIpAddress(),"1"（1 - 京东； 2 - 千寻； 3 - 海外购）,"1"（1 - 交易站点； 2 - 手机（含IPad）； 4 - 手Q； 5 - 微信； 7 - 只pc端或京致衣橱）,skuPromoSubtractList)**
   为 **tradeRequest** 对象赋值： **promoSubtract - promoSubtract**
11.打印 **"用户" + orderParam.getPin() + "京米erp下单入参: jsonStr="+JSON.toJSONString(tradeRequest)** 日志
12.调用京米促销erp下单jsf服务 **jmiTradeService.tradeOrder(tradeRequest)** 获取下单结果 **JmiTradeResponse jmiTradeResponse** jsf服务接口 **com.jd.jmi.trade.client.service.JmiTradeService**
13.获取是否下单成功的标识 **boolean success = jmiTradeResponse.isSuccess()**
14.判断是否下单成功 **success ？**
   Y： 获取返回数据 **JmiTradeOrder jmiTradeOrder = (JmiTradeOrder) jmiTradeResponse.getData()** 从返回数据中获取ERP订单号和uuid **orderid - jmiTradeOrder.getOrderId()； uuid - jmiTradeOrder.getUuid()**
   打印 **"用户" + orderParam.getPin() + "京米erp下单成功：orderid=" + orderid + " uuid=" + uuid** 日志
   为 **erpOrderResult** 对象赋值： **flag - true； message - "京米erp下单成功"； orderId - orderid**
   N： 获取错误信息 **responseMsg - jmiTradeResponse.getMsg()** 为 **erpOrderResult** 对象赋值： **flag - false； message - "京米erp下单失败,失败原因=" + responseMsg**
   打印 **"用户" + orderParam.getPin() + "京米erp下单失败,失败原因=" + responseMsg** 错误日志
   为 **erpOrderResult** 对象赋值： **erpOrderMoneyHasChange - false（用这个字段判断京米下单失败）**
   如果错误信息不为空 **responseMsg != null && responseMsg.length() > 0**
       用"_"分割错误信息 **String[] msgString = responseMsg.split("_")**
       如果可分割 **msgString != null && msgString.length > 0**
           如果不是虚拟资产校验失败或者不是虚拟镖局验证失败或者不是提交过快引起的失败 **!("4001".equals(msgString[0]) || "4002".equals(msgString[0]) ||responseMsg.indexOf("提交过快") >= 0)**
               记录国内机票erp下单发送错误监控信息
15.如果 4 到 14 的过程中出现自定义京米下单逻辑异常 **JmiParamException** 捕获异常并处理
       为 **erpOrderResult** 对象赋值： **flag - false； message - "京米erp下单失败,逻辑异常,一般由系统逻辑判断出错误返回,e=" + e； erpOrderMoneyHasChange - true**
       记录国内机票erp下单发送错误监控信息
       打印 **"用户" + orderParam.getPin() + "京米erp下单失败,逻辑异常", e** 错误日志
   如果是其它异常 捕获异常并处理
       为 **erpOrderResult** 对象赋值： **flag - false； message - "京米erp下单失败,系统异常,一般只指未知异常,如系统崩溃,e=" + e； erpOrderMoneyHasChange - true**
       记录国内机票erp下单发送错误监控信息
       打印 **"用户" + orderParam.getPin() + "京米erp下单失败,系统异常", e** 错误日志
16.注销国内机票erp下单监控
17.返回 **erpOrderResult** 对象

#### 记录失败次数

入口： com.jd.airplane.manager.alarm.impl.AlarmManagerImpl **public void airplaneAlarmCountTypeMessage(String intfKey, boolean isSuccess)**
日志： 未在log4j.xml中配置

1.根据入参 **intfKey** 在缓存中获取接口告警配置 **Map<String, Object> alarmMap - cacheUtils.getObject(intfKey)**
2.如果接口告警配置为空 **alarmMap == null**
  打印 **"获取" + intfKey + "告警配置信息：Memcached中告警配置信息为NULL！"** 日志 结束方法
3.获取告警类型 **int alarmType - alarmMap.get(MemcachAlarmConstants.ALARM_MAP_ALARM_TYPE)** 告警类型： **1 - 时间间隔； 2 - 连续次数**
4.如果告警类型不为连续次数 **alarmType != 2**
  打印 **"机票" + intfKey + "告警配置异常：ALARM_TYPE不是连续计数类型！"** 错误日志 结束方法
5.获取接口使用状态 **int useStatus - alarmMap.get(MemcachAlarmConstants.ALARM_MAP_USE_STATUS)** 使用状态： **0 - 停用； 1 - 使用**
6.如果接口在使用 **useStatus - 1**
  获取接口告警短信状态 **int alarmStatus - alarmMap.get(MemcachAlarmConstants.ALARM_MAP_ALARM_STATUS** 告警短信状态： **0 - 停用； 1 - 使用**
  获取接口调用失败次数 **int hasErrorCount - alarmMap.get(MemcachAlarmConstants.ALARM_MAP_HAS_ERROR_COUNT)**
  获取接口告警短信发送次数 **int hasSendCount - alarmMap.get(MemcachAlarmConstants.ALARM_MAP_HAS_SEND_COUNT)**
  获取接口调用失败规定最大次数 **final int alarmCount - alarmMap.get(MemcachAlarmConstants.ALARM_MAP_ALARM_COUNT)**
  获取接口告警短信发送规定最大次数 **final int smsCount - alarmMap.get(MemcachAlarmConstants.ALARM_MAP_SMS_COUNT)**
  判断接口调用是否成功 **isSuccess - true ？**
  Y： 将接口调用失败次数置为0 **hasErrorCount - 0**
  N： 将接口调用失败次数加1 **hasErrorCount - hasErrorCount + 1**
  如果接口调用失败次数超过接口调用失败规定最大次数 **hasErrorCount >= alarmCount** 需要短信报警
    设置短信发送标识 **boolean isSend = false**
	判断告警短信发送次数是否小于告警短信发送规定最大次数 **(hasSendCount + 1) <= smsCount ？**
	Y： 将短信发送标识置为true **isSend - true**
	N： 将短信发送标识置为false **isSend - false** (已经发送到最大短信数 停止发送短信) 
	    将接口告警短信发送次数置为0 **hasSendCount - 0**
	    将接口告警短信状态置为0（停用） **alarmStatus - 0**
	    根据id **alarmMap.get(MemcachAlarmConstants.ALARM_MAP_ID)** 更新数据库中的接口告警短信状态
  重新为alarmMap赋值 **HAS_ERROR_COUNT - hasErrorCount； HAS_SEND_COUNT - hasSendCount； ALARM_STATUS - alarmStatus**
  更新Memcached中的告警配置信息 **cacheUtils.replace(intfKey, 3600 * 24 * 30, alarmMap)**
7.如果上述过程中产生异常 捕捉异常进行处理 打印 **"机票" + intfKey + "警ERROR！"** 日志

#### 更新往返拆单订单信息

入口： com.jd.airplane.manager.ticket.impl.AirplaneOrderManagerImpl **public void updateOrderERPInfo(final Long oldMainOrderCode, final Long erpOrderId, final Long orderId, final Long orderIdSplit, final OrderSubmit orderSubmit)**
日志： 正式 - /export/Logs/jipiao.360buy.com/order-submit.log； 测试 - /export/Logs/logs_web/order-submit.log

1.放入一个缓存key： 主单erp+sku value： 订单号 支付时会用到 **jimdbCachedUtils.setEx(erpOrderId.toString() + "_" + TicketInsuranceSkuEnum.TICKETSKU1.getSku(), orderId.toString(), 60 * 60 * 24)** 有效时间1天
2.放入一个缓存key： 主单erp+sku value： 订单号 支付时会用到 **jimdbCachedUtils.setEx(erpOrderId.toString() + "_" + TicketInsuranceSkuEnum.TICKETSKU3.getSku(), orderIdSplit.toString(), 60 * 60 * 24)** 有效时间1天
3.根据旧的主订单号更新主单订单号和订单状态（1 - 下erp单成功(待付款)）： **airplaneMainOrderDao.updateErp(oldMainOrderCode, erpOrderId, 1)**
4.根据旧的主订单号和订单前置状态（-2 - 订单未确认）更新两条子单的父订单号和订单状态（1 - 下erp单成功(待付款)）： **airAirplaneOrderDao.updateSplitParentOrderCode(oldMainOrderCode, erpOrderId, -2, 1)**
5.根据旧的主订单号和新的主订单号 构建参数map map包含 **"orderIDNow" - erpOrderId； "orderIDBefore" - oldMainOrderCode** 更新联系人订单号： **airContactInfoDao.updateContactInfoOderId(map)**
6.根据参数map 更新行程单、保险发票等配送信息： **airDispatchInfoDao.updateDispatchInfoOderId(map)**
7.从入参中获取支付信息集合并遍历 **AirplaneOrderPaymentDetail orderPaymentDetail : orderSubmit.getAirplaneOrderPaymentDetails()**
  为 **orderPaymentDetail** 对象赋值： **id - sequenceUtil.get("AIR_ORDER_PAYMENT_DETAIL")； orderCode - erpOrderId**
  将 **orderPaymentDetail** 对象插入数据库中： **airAirplaneOrderDao.insertOrderPaymentDetail(orderPaymentDetail)**
8.如果在上述过程中出现异常 捕获异常并处理
  打印 **"split order update erp info error!", e** 错误日志
  回滚所有操作
  抛出异常 **throw new RuntimeException("split order update erp info error!", e)**

#### 更新订单信息

入口： com.jd.airplane.manager.ticket.impl.AirplaneOrderManagerImpl **public int updateOrderERPInfo(final OrderSubmit orderSubmit, final Long orderIdBefore)**
日志： 正式 - /export/Logs/jipiao.360buy.com/order-submit.log； 测试 - /export/Logs/logs_web/order-submit.log

1.构建 **final Map<String, Object> map** 对象
2.从入参中获取订单信息 **final AirAirplaneOrder order = orderSubmit.getOrder()**
3.从入参中获取联系信息 **final AirContactInfo contactInfo = orderSubmit.getContactInfo()**
4.为 **map** 对象赋值： **"orderCode" - order.getOrderCode()； "orderUUID" - order.getOrderUUID()； "orderStatus" - order.getOrderStatus()； "orderStatusBefore" - -2（订单未确认）； "paymentMethod" - order.getPaymentMethod()； "paymentMethodBefore" - order.getPaymentMethod()**
5.更新订单号、订单状态、支付模式： **airAirplaneOrderDao.updateOrderErpInfo(map)**
6.为 **map** 对象赋值： **"orderIDNow" - order.getOrderCode()； "orderIDBefore" - orderIdBefore**
7.更新乘客表中的ERP订单号： **airPassengerInfoDao.updatePassengerOderId(map)**
8.更新航班表中的ERP订单号： **airFlightInfoDao.updateFlightOderId(map)**
9.更新航班扩展表中的ERP订单号： **airFlightInfoExtendDao.updateFlightExpandOderId(map)**
10.更新联系人表中的ERP订单号： **airContactInfoDao.updateContactInfoOderId(map)**
11.更新配送表中的ERP订单号： **airDispatchInfoDao.updateDispatchInfoOderId(map)**
13.获取保险标识 **Long isSafe = order.getIsSafe()**
12.如果订单中存在保险 **isSafe == 1**
   调用保险系统的jsf服务接口更新ERP订单号： **boolean flag = airInsuranceFacadeWrap.updateOrderCode(orderIdBefore, order.getOrderCode())** jsf接口 **com.jd.air.insur.rpc.jsf.facade.AirInsuranceFacade**
   如果返回失败 **flag - false**
       打印 **"通知保险系统更新erp订单号失败！orderCodeOld="+orderIdBefore + ",orderCodeNew="+order.getOrderCode()** 错误日志
13.从入参中获取支付信息集合并遍历 **AirplaneOrderPaymentDetail orderPaymentDetail : orderSubmit.getAirplaneOrderPaymentDetails()**
  为 **orderPaymentDetail** 对象赋值： **id - sequenceUtil.get("AIR_ORDER_PAYMENT_DETAIL")； orderCode - order.getOrderCode()**
  将 **orderPaymentDetail** 对象插入数据库中： **airAirplaneOrderDao.insertOrderPaymentDetail(orderPaymentDetail)**
14.如果在 4 到 13 的处理过程中出现异常 捕获异常并处理
  回滚所有操作
  抛出异常 **throw new RuntimeException("updateOrderERPInfo" + order.getOrderCode() + "," + order.getOrderCode(), e)**
## 目前来看这个方法的返回值没有什么作用 建议修改返回类型
15.如果没有出现异常 返回0

#### 设置航班的退改签信息

入口： com.jd.airplane.service.refund.impl.RefundServiceImpl **public void setFlightRefundProvision(BookVO<?> bookVO)**
日志： 正式 - /export/Logs/jipiao.360buy.com/refund.log； 测试 - /export/Logs/logs_web/refund.log

1.调用 **getProvisionInfo(bookVO.getFlightGo(), bookVO)** 方法保存去程航班退改签信息
2.如果订单有返程 **bookVO.hasBackTrip()**
  调用 **getProvisionInfo(bookVO.getFlightBack(), bookVO)** 方法保存返程航班退改签信息
3.如果上述过程中出现异常 捕捉异常并处理
  打印 **"store the provision fail! e=", e** 错误日志
  如果上述过程中出现只能由Throwable捕捉的异常 捕捉异常并处理
  打印 **"store the provision fail! throwable's t=", t** 错误日志

#### 下单重新获取退改签费率及原始报文信息

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **public void getProvisionInfo(AirFlightInfo flightInfo, BookVO<?> bookVO)**
日志： 正式 - /export/Logs/jipiao.360buy.com/order-submit.log； 测试 - /export/Logs/logs_web/order-submit.log

1.调用 **initProvisionRequest(flightInfo)** 方法 构建 **SearchProvisionRequest searchProvisionRequest** 获取退改签请求对象
2.如果 **searchProvisionRequest** 对象不为空或者 **searchProvisionRequest** 对象中的商家id不为空或者 **searchProvisionRequest** 对象中的舱位价格map不为空 **null == searchProvisionRequest || StringUtils.isBlank(String.valueOf(searchProvisionRequest.getSourceId())) || null == searchProvisionRequest.getFlightSegment().getCabinPriceMap()**
  打印 **"订单提交——退改签信息查询参数为空! searchProvisionRequest=" + searchProvisionRequest.toString()** 日志
  退出方法
3.打印 **"The getProvisionInfo's obtain's searchProvisionRequest=" + JSON.toJSONString(searchProvisionRequest)** 日志
4.构建空的 **AirResponse<SearchProvisionResponse> iflightresponse** 对象
5.调用航班jsf接口查询航班退改签信息： **iflightresponse = airFlightService.searchProvision(searchProvisionRequest)** jsf接口 **com.jd.airplane.flight.service.IFlightService**
6.如果第 5 步处理过程中出现了异常
  打印 **"订单提交——退改签信息查询失败！", e** 错误日志
7.打印 **"The getProvisionInfo's obtain's iflightresponse=" + JSON.toJSONString(iflightresponse)** 日志
8.判断查询是否成功 **iflightresponse.checkSuccess() - true ？**
  Y： 
      获取退改签信息map **Map<PassengerEnum, Provision> ruleInfo = iflightresponse.getData().getProvision()**
	  如果退改签信息map不为空 **ruleInfo.isEmpty() - false**
	  调用 **initSearchProvisionResponse(iflightresponse.getData(), flightInfo)** 方法 将第三方退改签信息对象转化为机票系统的退改签信息对象： **com.jd.airplane.provision.response.SearchProvisionResponse response**
	  构建空的订单号对象 **Long erpOrderCode**
	  判断是否为往返拆单 **bookVO.getSplitFlag() - true ？**
	  	  Y： 为订单号赋值为父订单号 **erpOrderCode - bookVO.getOrderSubmit().getOrder().getParentOrderCode()** 
          N： 为订单号赋值 **erpOrderCode - bookVO.getOrderSubmit().getOrder().getOrderCode()**
      调用 **insertProvisionInfo(flightInfo, response, erpOrderCode, bookVO.getReverseUuid(), bookVO.getPin())** 方法 保存退改签系信息
      如果异常过程中出现异常 捕获异常并处理
          打印 **"订单提交——退改签信息保存失败！", e** 错误日志
   N： 
     根据订单号查询数据库获取订单信息 **AirAirplaneOrder orderInfo = orderManager.orderView(flightInfo.getOrderId().toString())** 
     调用 **createRefundFailApply(orderInfo, flightInfo)** 方法插入退票任务 
     打印 **"订单提交——退改签请求查询响应失败！"** 错误日志

#### 组装航班退改签信息查询请求对象

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private SearchProvisionRequest initProvisionRequest(AirFlightInfo flightInfo)**

1.构建 **SearchProvisionRequest searchProvisionRequest** 对象
2.为 **searchProvisionRequest** 对象赋值： **sourceId - Long.valueOf(flightInfo.getSourceId())； isNeedText - true； flightSegment - initProvisionSegment(flightInfo)**
3.返回 **searchProvisionRequest** 对象

#### 组装航班细节参数对象

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private FlightSegment initProvisionSegment(AirFlightInfo flightInfo)**

1.构建 **FlightSegment flightSegment** 对象
2.为 **flightSegment** 对象赋值： **airCorpCode - flightInfo.getAirCode()； depDate - DateConvertor.date2Str(flightInfo.getFlightDate(), EnumDateFormat.DATE_YMD（yyyy-MM-dd）)； depAirPortCode - flightInfo.getDeparture()； arrAirPortCode - flightInfo.getArrival()； fareItemId - flightInfo.getFareItemId()； policyId - flightInfo.getPolicyId()； seatType - StringUtil.isBlank(flightInfo.getSeatType())?null:Integer.parseInt(flightInfo.getSeatType())； cabinPriceMap - initCabinPriceMap(flightInfo)； productCode - flightInfo.getProductCode()； uniqueKey - CompanyEnum.COMPANY_CTRIPSPECIAL.getKey().equalsIgnoreCase(flightInfo.getSourceId())?flightInfo.getFareItemId():flightInfo.getUniqueKey()；**
3.返回 **flightSegment** 对象

#### 组装舱位价格map

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private Map<PassengerEnum, CabinPrice> initCabinPriceMap(AirFlightInfo flightInfo)**

1.构建 **Map<PassengerEnum, CabinPrice> priceItemMap** 对象 限制大小为3
2.构建 **CabinPrice adultItem** 对象
3.为 **adultItem** 对象赋值： **classCode - flightInfo.getSeatCode()； venderPrice - flightInfo.getVenderPrice().doubleValue()； originalPrice - flightInfo.getOriginalPrice().doubleValue()**
4.为 **priceItemMap** 对象赋值： **PassengerEnum.ADT - adultItem**
5.如果存在儿童座位并且儿童价格不为空并且儿童价格不为0 **StringUtils.isNotBlank(flightInfo.getChildSeatCode()) && null != flightInfo.getChildPrice() && flightInfo.getChildPrice() != 0**
  构建**CabinPrice childItem** 对象
  为 **childItem** 对象赋值： **classCode - flightInfo.getChildSeatCode()； venderPrice - flightInfo.getChildPrice().doubleValue()； originalPrice - flightInfo.getChildPrice().doubleValue()**
  为 **priceItemMap** 对象赋值： **PassengerEnum.CHD - childItem**
6.如果存在婴儿座位并且婴儿价格不为空并且婴儿价格不为0 **StringUtils.isNotBlank(flightInfo.getInfantSeatCode()) && null != flightInfo.getInfantVenderPrice() && flightInfo.getInfantVenderPrice() != 0**
  构建**CabinPrice infItem** 对象
  为 **infItem** 对象赋值： **classCode - flightInfo.getInfantSeatCode()； venderPrice - flightInfo.getInfantVenderPrice().doubleValue()； originalPrice - flightInfo.getInfantVenderPrice().doubleValue()**
  为 **priceItemMap** 对象赋值： **PassengerEnum.INF - infItem**
7.返回 **priceItemMap** 对象

#### 将第三方退改签信息转换为本地退改签信息

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private com.jd.airplane.provision.response.SearchProvisionResponse initSearchProvisionResponse(SearchProvisionResponse data, AirFlightInfo flightInfo)**

1.构建 **com.jd.airplane.provision.response.SearchProvisionResponse target** 对象
2.为 **target** 对象赋值： **requestText - data.getRequestText()； responseText - data.getResponseText()； provision - initProvisons(data.getProvision(), flightInfo)**
3.返回 **target** 对象

#### 将第三方退改签规则信息map转换为本地退改签规则信息map

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private Map<com.jd.airplane.provision.enums.PassengerEnum, com.jd.airplane.provision.response.Provision> initProvisons(Map<PassengerEnum, Provision> provision, AirFlightInfo flightInfo)**

1.构建 **Map<com.jd.airplane.provision.enums.PassengerEnum, com.jd.airplane.provision.response.Provision> target** 对象
2.遍历退改签规则 **Map.Entry<PassengerEnum, Provision> entry: provision.entrySet()**
  如果是成人 **com.jd.airplane.provision.enums.PassengerEnum.ADT.getCode() == entry.getKey().getCode()**
      构建字符串变量**StringBuilder classNoCn**
      调用 **getClassText(flightInfo.getAirCode(), flightInfo.getSeatCode(), flightInfo.getFlightDate(),new Date())** 方法构建舱位信息 追加至 **classNoCn** 对象中
      在 **classNoCn** 对象后追加： **"("； flightInfo.getSeatCode()； ")"**
      为 **target** 对象赋值： **com.jd.airplane.provision.enums.PassengerEnum.ADT, initProvision(entry.getValue(), classNoCn.toString(), flightInfo.getOriginalPrice())**
  如果是儿童 **com.jd.airplane.provision.enums.PassengerEnum.CHD.getCode() == entry.getKey().getCode()**
      构建字符串变量**StringBuilder classNoCn**
      调用 **getClassText(flightInfo.getAirCode(), flightInfo.getChildSeatCode(), flightInfo.getFlightDate(),new Date())** 方法构建舱位信息 追加至 **classNoCn** 对象中
      为 **target** 对象赋值： **com.jd.airplane.provision.enums.PassengerEnum.CHD, initProvision(entry.getValue(), classNoCn.toString(), flightInfo.getChildPrice())**
  如果是婴儿 **com.jd.airplane.provision.enums.PassengerEnum.INF.getCode() == entry.getKey().getCode()**
      为 **target** 对象赋值： **com.jd.airplane.provision.enums.PassengerEnum.INF, initProvision(entry.getValue(), "", flightInfo.getInfantVenderPrice())**
3.返回 **target** 对象

#### 获取舱位等级描述信息

入口： com.jd.airplane.manager.util.BaseDataUtil **public String getClassText(String airways, String classCode, Date deptDate, Date saleEffectDate)**
日志： 正式 - /export/Logs/jipiao.360buy.com/flight-data.log； 测试 - /export/Logs/logs_web/flight-data.log

1.构建字符串 **text - "经济舱"**
2.构建字符串 **msg - "getClassText : airways=" + airways + ",classCode=" + classCode**
3.如果出发时间不为空 **deptDate != null**
  修改 **msg** 对象追加起飞时间： **msg += ",deptDate=" + deptDate.getTime()**
4.如果有效下单时间不为空 **saleEffectDate != null**
  修改 **msg** 对象追加有效下单时间时间： **msg += ",saleEffectDate=" + saleEffectDate.getTime()**
5.打印 **msg** 日志
6.调用 **getCabinInfo(airways, classCode, deptDate, saleEffectDate)** 方法 获取 **CabinResponse cabin** 对象
7.如果 **cabin** 对象为空或者舱位等级为空 **cabin == null || StringUtils.isBlank(cabin.getSeatLevel())**
  返回 **text** 对象
8.根据舱位等级获取舱位信息 **ClassLevelEnum classLevelEnum = ClassLevelEnum.parseByCode(cabin.getSeatLevel())**
9.如果舱位信息为空 **classLevelEnum == null**
  返回 **text** 对象
10.为 **text** 对象重新赋值： **text - classLevelEnum.getDes()**
11.如果 **cabin** 对象中的舱位等级中文描述不为空 **StringUtils.isNotBlank(cabin.getSeatLevelCh()) - true**
   修改 **text** 对象追加舱位等级中文描述： **text - cabin.getSeatLevelCh().concat(text)**
12.如果 2 到 11 处理过程中出现异常 捕捉异常并进行处理
   打印 **"BaseDataUtil getClassLevel is error .", e** 错误日志
13.返回 **text** 对象

#### 获取舱位信息

入口： com.jd.airplane.util.BaseDataClient **public CabinResponse getCabinInfo(String airways, String classNo, Date effectTakeoffDate, Date saleEffectDate)**
日志： 正式 - /export/Logs/jipiao.360buy.com/flight-data.log； 测试 - /export/Logs/logs_web/flight-data.log

1.如果航司码为空或者舱位代码为空 **StringUtils.isBlank(airways) || StringUtils.isBlank(classNo)**
  返回 NULL
2.构建 **CabinRequest request** 对象
3.构建 **AirwaysSeatVo item** 对象
4.为 **item** 对象赋值： **airways - airways； seat - classNo； effectTakeoffDate - effectTakeoffDate（起飞有效期）； saleEffectDate - saleEffectDate（销售有效期）**
5.构建 **Set<AirwaysSeatVo> set** 对象
6.调用 **poressDateFormat(AirwaysSeatVo item)** 方法格式化时间
7.将 **item** 对象添加到 **set** 对象中
8.为 **request** 对象赋值： **airwaysSeatVoSet - set**
9.打印 **"CabinRequest json : " + JSON.toJSONString(request)** 日志
10.调用基础数据jsf接口获取舱位信息： **BaseDataCommonResponse<Map<String, CabinResponse>> response = this.baseDataCommonService.getCabinInfo(request)** jsf接口： **com.jd.basedata.service.BaseDataCommonService**
11.打印 **"CabinResponse json : " + JSON.toJSONString(response)** 日志
12.如果调用返回结果为空或者返回码不是"0000"（成功）或者返回结果中的数据为空 **response == null || !"0000".equals(response.getResponseCode()) || MapUtils.isEmpty(response.getData())**
   返回 NULL
13.遍历返回结果中的数据 **Map.Entry<String, CabinResponse> entry : response.getData().entrySet()**
   返回 **entry.getValue()**
14.如果 2 到 13 处理过程中出现了异常 捕捉异常并处理
   打印 **"baseDataCommonService get a CabinInfo is error .", e** 错误日志
15.返回 NULL

#### 格式化时间

入口： com.jd.airplane.util.BaseDataClient **private void poressDateFormat(AirwaysSeatVo item) throws Exception**

1.构建时间格式化对象 **SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd")**
2.格式化入参 **item** 对象的时间： **effectTakeoffDate - format.parse(format.format(item.getEffectTakeoffDate()))（起飞有效期）； saleEffectDate - format.parse(format.format(item.getSaleEffectDate()))（销售有效期）**

#### 将第三方退改签规则信息转换为本地退改签规则信息

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private com.jd.airplane.provision.response.Provision initProvision(Provision value, String classNoCn, Long originalPrice)**

1.如果退改签规则信息为空 **null == value**
  返回 NULL
2.构建 **com.jd.airplane.provision.response.Provision target** 对象
3.为 **target** 对象赋值： **discountPrice - value.getDiscountPrice()； freightPrice - value.getFreightPrice()； originalPrice - null==value.getOriginalPrice()?new BigDecimal(originalPrice):value.getOriginalPrice()； classNoCn - classNoCn； ruleInfo - initRuleInfo(value.getRuleInfo(),originalPrice)**
4.返回 **target** 对象

#### 将第三方规则信息map转换为本地规则信息map

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private Map<com.jd.airplane.provision.enums.ProvisionTypeEnum, Object> initRuleInfo(Map<ProvisionTypeEnum, Object> ruleInfo,Long price)**

1.如果信息map为空 **ruleInfo.isEmpty() - true**
  返回 NULL
2.构建 **Map<com.jd.airplane.provision.enums.ProvisionTypeEnum, Object> target** 对象
3.获取行李额信息： **luggallow - (null == ruleInfo.get(ProvisionTypeEnum.LUGGALLOW)|| StringUtil.isBlank(String.valueOf(ruleInfo.get(ProvisionTypeEnum.LUGGALLOW))))?"":String.valueOf(ruleInfo.get(ProvisionTypeEnum.LUGGALLOW))**
4.获取餐食信息： **(meal - null == ruleInfo.get(ProvisionTypeEnum.MEALINFO)|| StringUtil.isBlank(String.valueOf(ruleInfo.get(ProvisionTypeEnum.MEALINFO))))?"":String.valueOf(ruleInfo.get(ProvisionTypeEnum.MEALINFO))**
5.遍历入参信息map **Map.Entry<ProvisionTypeEnum, Object> entry: ruleInfo.entrySet()**
  如果是改期规定 **com.jd.airplane.provision.enums.ProvisionTypeEnum.CHANGE.getCode() == entry.getKey().getCode()**
      为 **target** 对象赋值： **com.jd.airplane.provision.enums.ProvisionTypeEnum.CHANGE - entry.getValue()**
  如果是改期规定列表 **com.jd.airplane.provision.enums.ProvisionTypeEnum.CHANGE_RULES.getCode() == entry.getKey().getCode()**
      为 **target** 对象赋值： **com.jd.airplane.provision.enums.ProvisionTypeEnum.CHANGE_RULES - initProvisonRules(entry.getValue(),price)**
  如果是签转规定 **com.jd.airplane.provision.enums.ProvisionTypeEnum.ENDORSE.getCode() == entry.getKey().getCode()**
      为 **target** 对象赋值： **com.jd.airplane.provision.enums.ProvisionTypeEnum.ENDORSE - entry.getValue())**
  如果是行李信息 **com.jd.airplane.provision.enums.ProvisionTypeEnum.LUGGALLOW.getCode() == entry.getKey().getCode()**
      为 **target** 对象赋值： **com.jd.airplane.provision.enums.ProvisionTypeEnum.LUGGALLOW - luggallow)**
  如果是餐食信息 **com.jd.airplane.provision.enums.ProvisionTypeEnum.MEALINFO.getCode() == entry.getKey().getCode()**
      为 **target** 对象赋值： **com.jd.airplane.provision.enums.ProvisionTypeEnum.MEALINFO - meal)**
  如果是退票规定 **com.jd.airplane.provision.enums.ProvisionTypeEnum.REFUND.getCode() == entry.getKey().getCode()**
      为 **target** 对象赋值： **com.jd.airplane.provision.enums.ProvisionTypeEnum.REFUND - entry.getValue()**
  如果是退票规定列表 **com.jd.airplane.provision.enums.ProvisionTypeEnum.REFUND_RULES.getCode() == entry.getKey().getCode()**
      为 **target** 对象赋值： **com.jd.airplane.provision.enums.ProvisionTypeEnum.REFUND_RULES - initProvisonRules(entry.getValue(),price)**
6.为 **target** 对象赋值： **com.jd.airplane.provision.enums.ProvisionTypeEnum.EXTENDS,luggallow +(StringUtil.isBlank(meal)?"":("," + meal))** 扩展信息
7.返回 **target** 对象

#### 将第三方退改签规定列表转换为本地退改签规定列表

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private Object initProvisonRules(Object value,Long price)**
日志： 正式 - /export/Logs/jipiao.360buy.com/order-submit.log； 测试 - /export/Logs/logs_web/order-submit.log

1.如果退改签规则信息为空 **null == value**
  返回 NULL
2.获取原始退票规定列表 **List<RefundRule> original = (List<RefundRule>)value**
3.构建 **List<com.jd.airplane.provision.response.RefundRule> target** 对象
4.遍历原始退票规定列表 **RefundRule refundRule: original**
  构建 **com.jd.airplane.provision.response.RefundRule targetRefundRule** 对象
  获取手续费 **BigDecimal fee = refundRule.getFee()**
  获取最低手续费 **BigDecimal lowestRefundFee = refundRule.getLowestRefundFee()==null?new BigDecimal(0):refundRule.getLowestRefundFee()**
  获取票价 **BigDecimal ticketPrice = new BigDecimal(price)**
  判断票价是否高于最低手续费 **ticketPrice.compareTo(lowestRefundFee) > 0**
      Y： 如果手续费是否高于票价 **fee.compareTo(ticketPrice) > 0** 则取手续费等于票价 **fee = ticketPrice** 如果手续费低于最低手续费 **fee.compareTo(lowestRefundFee) < 0** 则取手续费等于最低手续费 **fee = lowestRefundFee**
      N： 打印 **"票价低于最低手续费！ticketPrice = " + ticketPrice.doubleValue() + ",lowestRefundFee = " + lowestRefundFee.doubleValue()** 错误日志
  为 **targetRefundRule** 对象赋值： **fee - fee； include - refundRule.getInclude()； lowestRefundFee - lowestRefundFee； numOfTime - refundRule.getNumOfTime()； rate - refundRule.getRate()； timePoint - initTimePoint(refundRule.getTimePoint())； timeType - initTimeType(refundRule.getTimeType())； timeUnit - initTimeUnit(refundRule.getTimeUnit())**
  将 **targetRefundRule** 对象添加到 **target** 对象中
5.返回 **target** 对象

#### 将第三方时间点转换为本地时间点

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private com.jd.airplane.provision.enums.TimePointEnum initTimePoint(TimePointEnum timePoint)**

1.如果入参为空 **null == timePoint**
  返回 NULL
2.如果是起飞前 **com.jd.airplane.provision.enums.TimePointEnum.BEFORE.getCode() == timePoint.getCode()**
  返回 **com.jd.airplane.provision.enums.TimePointEnum.BEFORE**
3.如果是起飞后 **com.jd.airplane.provision.enums.TimePointEnum.AFTER.getCode() == timePoint.getCode()**
  返回 **com.jd.airplane.provision.enums.TimePointEnum.AFTER**
4.返回 NULL

#### 将第三方时间类型转换为本地时间类型

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private com.jd.airplane.provision.enums.TimeTypeEnum initTimeType(TimeTypeEnum timeType)**

1.如果入参为空 **null == timeType**
  返回 NULL
2.如果是起飞前 **com.jd.airplane.provision.enums.TimeTypeEnum.BEFORE_DEPARTURE.getCode() == timePoint.getCode()**
  返回 **com.jd.airplane.provision.enums.TimeTypeEnum.BEFORE_DEPARTURE**
3.如果是起飞后 **com.jd.airplane.provision.enums.TimeTypeEnum.AFTER_DEPARTURE.getCode() == timePoint.getCode()**
  返回 **com.jd.airplane.provision.enums.TimeTypeEnum.AFTER_DEPARTURE**
4.返回 NULL  

#### 将第三方时间格式转换为本地时间格式

入口： com.jd.airplane.service.order.impl.OrderDataCenterServiceImpl **private com.jd.airplane.provision.enums.TimeUnitEnum initTimeUnit(TimeUnitEnum timeUnit)**

1.如果入参为空 **null == timeUnit**
  返回 NULL
2.如果是起飞前 **com.jd.airplane.provision.enums.TimeUnitEnum.HOUR.getCode() == timePoint.getCode()**
  返回 **com.jd.airplane.provision.enums.TimeUnitEnum.HOUR**
3.如果是起飞后 **com.jd.airplane.provision.enums.TimeUnitEnum.DAY.getCode() == timePoint.getCode()**
  返回 **com.jd.airplane.provision.enums.TimeUnitEnum.DAY**
4.返回 NULL

#### 保存退改签信息

入口： com.jd.airplane.manager.order.impl.OrderManagerImpl **public void insertProvisionInfo(AirFlightInfo flightInfo, SearchProvisionResponse response, Long erpOrderCode, String reverseUuid, String pin)**
日志： 正式 - /export/Logs/jipiao.360buy.com/order-manager.log； 测试 - /export/Logs/logs_web/order-manager.log

1.调用 **getRefundProvisionKey(erpOrderCode, flightInfo.getId())** 获取缓存的key值 
  将退改签信息放入缓存中 **jdCacheUtils.setEx(RefundUtils.getRefundProvisionKey(erpOrderCode, flightInfo.getId()) ,JSON.toJSONString(response), 864000l)** 缓存有效期为10天
2.如果上述过程中出现异常 捕获异常并处理
  ## 代码中用了 info 等级而不是 error 等级 建议修改为error
  打印 **"退改签信息插入缓存失败！orderCode=" + erpOrderCode + "flightId=" + flightInfo.getId(), e** 错误日志
3.获取航班销售限制缓存key值 **key - "air.order.saleLimitInfo." + reverseUuid + "." + pin**
4.根据航班销售限制缓存key获取航班销售限制信息 **SaleLimitInfo saleLimitInfo = jdCacheUtils.get(key, SaleLimitInfo.class)**
5.打印 **"航班id" + flightInfo.getId() + ",订单" + erpOrderCode + ", after erp order put salelimitinfo to es:=" + JSON.toJSONString(saleLimitInfo)** 日志
6.调用 **writeProvisionInfoToES(flightInfo, response, erpOrderCode, saleLimitInfo)** 方法将退改签信息保存到ES中

#### 组装退改签信息缓存key值

入口： com.jd.airplane.manager.refund.RefundUtils **public static String getRefundProvisionKey(Long orderCode, Long flightId)**

返回 **"refund_provision_info" + ":" + orderCode + ":" + flightId**

#### 将退改签信息保存到ES中

入口： com.jd.airplane.manager.order.impl.OrderManagerImpl **private void writeProvisionInfoToES(AirFlightInfo flightInfo, SearchProvisionResponse response, Long erpOrderCode, SaleLimitInfo saleLimitInfo)**
日志： 正式 - /export/Logs/jipiao.360buy.com/order-manager.log； 测试 - /export/Logs/logs_web/order-manager.log

1.打印 **"航班id" + flightInfo.getId() + ",订单" + erpOrderCode + "开始保存退改签信息"** 日志
2.构建退改签原始报文 - ES映射关系对象 **ProvisionRuleESInfo esInfo**
3.为 **esInfo** 对象赋值： **id - sequenceUtil.get("AIR_PROVISION_RULE_ES_ID")； orderCode - String.valueOf(erpOrderCode)； flightId - String.valueOf(flightInfo.getId())； airplaneNumberflightInfo.getAirplaneNumber()； seatCode - flightInfo.getSeatCode()； venderId - flightInfo.getSourceId()； requestMsg - response.getRequestText()； responseMsg - response.getResponseText()； frontResponseMsg - JSON.toJSONString(response)； saleLimitInfo - JSON.toJSONString(saleLimitInfo)； insertTime - new Date()**
4.构建 **ESCreateSelector esCreateSelector** 对象
5.为 **esCreateSelector** 对象赋值： **id - String.valueOf(esInfo.getId())； content； tcp - false**
6.调用退改签es服务接口保存退改签信息 **ESResult esResult = provisionRuleEsClientOperations.createRowData(esCreateSelector)**
7.如果调用返回结果为空或者调用返回结果为失败 **esResult == null || ! esResult.isSuccess()**
  往外抛出异常 **throw new RuntimeException("创建CreateRowData异常---------返回值为空或者返回失败，失败原因" + esResult == null ? "null" : esResult.getContent())**
8.如果上述过程中出现异常 捕捉异常并处理
  打印 **"插入原始退改签原始报文写入ES失败" + flightInfo.getId() + ", orderCode=" + erpOrderCode, e** 错误日志

#### 如果下单后没有退改签规则 需要创建无效退票申请记录 防止下单成功后用户在线申请退票

入口： com.jd.airplane.manager.ticket.impl.RefundTicketManagerImpl **public void createRefundFailApply(final AirAirplaneOrder orderInfo,final AirFlightInfo flightInfo)**
日志： 正式 - /export/Logs/jipiao.360buy.com/refund-online.log； 测试 - /export/Logs/logs_web/refund-online.log

1.构建无效退票申请记录id **final Long businessApplyId = sequenceUtil.get(""AIR_BUSINESS_APPLY_INFO_ID"")**
2.构建无效退票申请记录对象 **AirBusinessApplyInfo applyInfo**
3.为 **applyInfo** 对象赋值： **id - businessApplyId； businessType - 1（在线退票）； subType - 1（自愿申请退票）； orderCode - orderInfo.getOrderCode()； orderCd - orderInfo.getOrderCd()； venderId - Integer.valueOf(orderInfo.getSourceId().toString())； status - 9（无效状态）； sendTimes - 0； commitSource - 2（来自系统提交）； userPin - "system"**
4.调用 **airBusinessApplyInfoDao.insertBusinessApplyInfo(applyInfo)** 方法 将无效退票申请记录保存至数据库
5.构建 **AirBusinessOpt airBusinessOpt** 对象
6.为 **airBusinessOpt** 对象赋值： **businessApplyId - businessApplyId； msgType - 1（退改签政策缺失无法退票）； msg - "航班号="+flightInfo.getAirplaneNumber()+",舱位="+flightInfo.getSeatCode()； isDisplay - 0（不展示）；processStatus - 0（异常）**
7.调用 **insertBusinessOptInfo(airBusinessOpt)** 方法 将退票操作记录保存至数据库

#### 将退票操作记录保存至数据库

入口： com.jd.airplane.manager.ticket.impl.RefundTicketManagerImpl **public void insertBusinessOptInfo(AirBusinessOpt airBusinessOpt)**

1.为入参 **** 对象赋值： **id - sequenceUtil.get("AIR_BUSINESS_OPT_ID")； dealStatus - 0（未处理）； commitSource - null； userPin - null； remark - null； optType - 1（log-退票操作记录）**
2.调用 **airBusinessOptDao.insertBusinessOptInfo(airBusinessOpt)** 方法 将退票操作记录保存至数据库

#### 判断是否为航司

入口： com.jd.airplane.util.AirCompanyUtil **public static boolean isAirCompany(String sourceId)**

航司：首都航空 - 86385
      深圳航空 - 106706
      国际航空 - 138669
      海南航空 - 616106
      东方航空 - 616066
      南方航空 - 615927
      新深航(走T+0系统) - 正式 661726 测试 66301
      春秋航空 - 正式 650446 测试 66361
      厦门航空 - 正式 649306 测试 66363
      天津航空 - 正式 660846 测试 66362
      四川航空 - 正式 699349 测试 66721
      祥鹏航空 - 正式 700566 测试 66763
      九元航空 - 正式 687287 测试 66762
      奥凯航空 - 正式 741310 测试 67241
      河北航空 - 正式 765908 测试 67623
      吉祥航空 - 正式 770775 测试 67742

#### 机票保险SKU枚举类

入口： com.jd.airplane.enumtype.TicketInsuranceSkuEnum
	   TICKETSKU1  - 国内单程成人机票sku - 线上 1000289361  测试 10000537602
	   TICKETSKU3  - 国内往返成人机票sku - 线上 1000289289  测试 10000252520
	   TICKETSKU2  - 国内单程儿童机票sku - 线上 1000289291  测试 10000252519
	   TECKETSKU4  - 国内往返儿童机票sku - 线上 1000289283  测试 10000252521
	   TICKETSKU12 - 国内单程婴儿机票sku - 线上 14184595712 测试 10000337601
	   TICKETSKU13 - 国内往返婴儿机票sku - 线上 14184649345 测试 10000448801
       
       INSURANCESKU1      - 国内20元航空意外险     - 线上 1006961176  测试 10000252522
       INSURANCESKU2      - 国内30元航空意外险     - 线上 1585531673  测试 10000252523
       INSURANCESKU3      - 国内30元航空延误险     - 线上 27415317881 测试 27415317881
       INSURANCESKU1_BACK - 国内返程20元航空意外险 - 线上 1006961176  测试 18735019992
       INSURANCESKU2_BACK - 国内返程30元航空意外险 - 线上 1585531673  测试 18734886075
       INSURANCESKU3_BACK - 国内返程30元航空延误险 - 线上 27663150335 测试 27663150335

#### 风控航司二字码映射常量

入口： com.jd.airplane.domain.riskcontrol.FlightRiskControlAirCodeConstants

    CZ(1812524l, "南方航空")   FM(1450374l, "上海航空")   HU(6862391l, "海南航空")      MF(4856191l, "厦门航空")      MU(3996011l, "东方航空"),
    SC(9391941l, "山东航空")   _3U(8008099l, "四川航空")  ZH(9017325l, "深圳航空")      BK(2516740l, "奥凯航空")      EU(5908471l, "成都航空"),
    KN(4044603l, "联合航空")   _8L(3812071l, "祥鹏航空")  _8C(5842471l, "东星航空")     HO(8599472l, "吉祥航空")      G5(2442756l, "华夏航空"),
    CA(7067344l, "中国国航")   PN(4389587l, "西部航空")   GS(4538870l, "天津航空")      _9C(7684436l, "春秋航空")     NS(4683796l, "河北航空"),
    CN(6853573l, "大新华航空") VD(4549585l, "鲲鹏航空")   OQ(2681158l, "重庆航空")      HX(2625277l, "香港航空公司")  JD(5904649l, "首都航空"),
    KY(6575871l, "昆明航空")   JR(1913407l, "幸福航空")   TV(4642740l, "西藏航空公司")  QW(7354487l, "青岛航空")      DR(3134005l, "瑞丽航空"),
    GJ(2631179l, "长龙航空")   DZ(1667162l, "东海航空")   UQ(2125870l, "乌鲁木齐航空")  FU(5013436l, "福州航空")      GX(7253052l, "北部湾航空"),
    AQ(8144413l, "九元航空")   YI(5360326l, "英安航空")   RY(2715327l, "江西航空")      Y8(6899787l, "扬子江航空")    GY(1434459l, "多彩贵州航空"), 
    A6(1126399l, "红土航空")   LT(8167506l, "龙江航空")   GT(6218575l, "桂林航空")

#### 第三方乘机人类型枚举类

入口： com.jd.airplane.infra.bean.enums.PassengerEnum

    ADT(1, "ADT", "成人") CHD(2, "CHD", "儿童") INF(3, "INF", "婴儿")

#### 机票系统乘机人类型枚举类

入口： com.jd.airplane.provision.enums.PassengerEnum

    ADT(1, "ADT", "成人") CHD(2, "CHD", "儿童") INF(3, "INF", "婴儿")

#### 舱位等级枚举类

入口： com.jd.airplane.enumtype.ClassLevelEnum

    ECONOMY("Y","1", "Economy", "经济舱") BUSINESS("C", "2", "Business", "商务舱") FIRST("F", "3","First", "头等舱")

#### 第三方退改签规则类型枚举类

入口： com.jd.airplane.flight.model.enums.ProvisionTypeEnum
    
    REFUND(1, "refund", "退票规定")
    CHANGE(2, "change", "改期规定")
    ENDORSE(3, "endorse", "签转规定")
    REFUND_RULES(4, "refund_rules", "退票规定列表")
    CHANGE_RULES(5, "endorse_rules", "改期规定列表")
    EXTENDS(6, "extendsInfo", "扩展信息")
    LUGGALLOW(7, "luggallow", "行李信息")
    MEALINFO(8, "mealInfo", "餐食信息")

#### 机票系统退改签规则类型枚举类

入口： com.jd.airplane.provision.enums.ProvisionTypeEnum

    REFUND(1, "refund", "退票规定", 3)
    CHANGE(2, "change", "改期规定", 4)
    ENDORSE(3, "endorse", "签转规定", 5)
    REFUND_RULES(4, "refund_rules", "退票规定列表", 1)
    CHANGE_RULES(5, "endorse_rules", "改期规定列表", 2)
    EXTENDS(6, "extendsInfo", "扩展信息", 6)
    LUGGALLOW(7, "luggallow", "行李信息", 7)
    MEALINFO(8, "mealInfo", "餐食信息", 8)

#### 第三方时间点类型枚举类

入口： com.jd.airplane.flight.model.enums.TimePointEnum
    
    BEFORE(1, "2", "前") AFTER(2, "-2", "后")

#### 机票系统时间点类型枚举类

入口： com.jd.airplane.provision.enums.TimePointEnum
    
    BEFORE(1, "2", "前") AFTER(2, "-2", "后")

#### 第三方时间类型枚举类

入口： com.jd.airplane.flight.model.enums.TimeTypeEnum
    
    BEFORE_DEPARTURE(1, "1", "起飞前") AFTER_DEPARTURE(2, "-1", "起飞后")

#### 机票系统时间类型枚举类

入口： com.jd.airplane.provision.enums.TimeTypeEnum
    
    BEFORE_DEPARTURE(1, "1", "起飞前") AFTER_DEPARTURE(2, "-1", "起飞后")

#### 第三方时间格式枚举类

入口： com.jd.airplane.flight.model.enums.TimeUnitEnum
    
    HOUR(1, "H", "小时") DAY(2, "D", "天")

#### 机票系统时间格式枚举类

入口： com.jd.airplane.provision.enums.TimeUnitEnum
    
    HOUR(1, "H", "小时") DAY(2, "D", "天")